exports.ids = ["4a82"];
exports.modules = {

/***/ "5m9w":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("# Academics of Sushant\r\n\r\n<table>\r\n    <tr>\r\n        <th>Period</th>\r\n        <th>Institute</th>\r\n        <th>Stream</th>\r\n    </tr>\r\n    <tr>\r\n        <td>1982 - 1986</td>\r\n        <td><a target='_blank' href='https://www.bitmesra.ac.in/'>Birla Institute Of Technology, Mesra</a></td>\r\n        <td> B.Tech (Computer Science). Topped in the branch</td>\r\n    </tr>\r\n    <tr>\r\n        <td>1980 - 1982</td>\r\n        <td><a target='_blank' href='https://www.scottishchurch.ac.in/'>Scottish Church College</a>. (Pure Science) 63.2% marks</td>\r\n        <td>Class 11 + 12</td>\r\n    </tr>\r\n    <tr>\r\n        <td>1976 – 1980</td>\r\n        <td><a target='_blank' href='https://birlahighschool.com/'>Birla High School</a></td>\r\n        <td>Class 6 – Class 10. CBSE score was 80%</td>\r\n    </tr>\r\n    <tr>\r\n        <td>1975</td>\r\n        <td><a target='_blank' href='https://birlahighschool.com/'>Junior Hindi High School</a></td>\r\n        <td>Class 5</td>\r\n    </tr>\r\n    <tr>\r\n        <td>1969 – 1974</td>\r\n        <td><a target='_blank' href='https://abhinavbharati.co.in/'>Abhniv Bharti</a></td>\r\n        <td> Class KG to Class 4. (Montessori)</td>\r\n    </tr>\r\n</table>\r\n\r\nI was always good in Alzebra and Science group. I had interest in English and Hindi languages. I can speak Bengali.\r\n\r\nMy educational certificates are below:\r\n<div><a target='_blank' href='/static/documents/sushant-agrawal-higher-secondary-mark-sheet.pdf'>Higher Secondary mark Sheet</a></div>\r\n<div><a target='_blank' href='/static/documents/susantagrawal_engineering-degree.pdf'>B.Tech. Engineering Degree</a></div>\r\n\r\n<style>\r\n    table {\r\n        border-collapse: collapse;\r\n        /* width:90%; */\r\n    }\r\n\r\n\r\n    td, th {\r\n        border: 1px solid lightGrey;    \r\n        padding: 0.3rem;\r\n        /* margin:1rem; */\r\n    }\r\n    td {\r\n        font-size: 1.0rem;\r\n    }\r\n    p {\r\n        font-size: 1rem;\r\n    }\r\n    h1 {\r\n        font-size: 1.5rem;\r\n    }\r\n</style>");

/***/ })

};;