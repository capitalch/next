module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/+P4":
/***/ (function(module, exports, __webpack_require__) {

var _Object$getPrototypeOf = __webpack_require__("Bhuq");

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = _Object$setPrototypeOf ? _Object$getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || _Object$getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

module.exports = _getPrototypeOf;

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "/HRN":
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ 2:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("OlXl");


/***/ }),

/***/ "2Eek":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("ltjX");

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "5M6V":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__("doui");

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// CONCATENATED MODULE: ./components/header.tsx




var StyledMenuIcon = external_styled_components_default.a.div.withConfig({
  displayName: "header__StyledMenuIcon",
  componentId: "sc-1w6dzkt-0"
})(["div{width:35px;height:5px;background-color:#fff;margin:6px 0;}margin:0.5rem;margin-left:2rem;cursor:pointer;@media only screen and (min-width:993px){display:none;}"]);
var StyledMenuItems = external_styled_components_default.a.ul.withConfig({
  displayName: "header__StyledMenuItems",
  componentId: "sc-1w6dzkt-1"
})(["display:flex;flex-direction:column;width:60%;a{text-decoration:none;display:block;margin-left:1.3rem;margin-top:0.3rem;margin-bottom:0.3rem;font-size:1.3rem;color:#fff;}li{list-style-type:none;border:1px solid white;border-collapse:collapse;}@media only screen and (min-width:993px){flex-direction:row;align-items:center;li{border:0px;}}.active{color:red;}"]);
var StyledHeader = external_styled_components_default.a.nav.withConfig({
  displayName: "header__StyledHeader",
  componentId: "sc-1w6dzkt-2"
})(["grid-area:header;background-color:black;display:flex;justify-content:space-between;"]);
var StyledActiveMenuItem = external_styled_components_default.a.span.withConfig({
  displayName: "header__StyledActiveMenuItem",
  componentId: "sc-1w6dzkt-3"
})(["font-weight:700;font-size:1.3rem;margin:auto 1rem;color:#fff;text-transform:capitalize;@media only screen and (min-width:993px){display:none;}"]);
var StyledPortfolio = external_styled_components_default.a.span.withConfig({
  displayName: "header__StyledPortfolio",
  componentId: "sc-1w6dzkt-4"
})(["font-size:1rem;font-weight:bold;color:#fff;margin-left:auto;margin-top:auto;margin-bottom:auto;margin-right:0.5rem;"]);

function MenuIcon(_ref) {
  var show = _ref.show,
      setShow = _ref.setShow,
      portfolio = _ref.portfolio,
      setPortfolio = _ref.setPortfolio;
  return external_react_default.a.createElement(StyledMenuIcon, {
    onClick: function onClick() {
      setShow(!show);
      setPortfolio(!portfolio);
    }
  }, external_react_default.a.createElement("div", null), external_react_default.a.createElement("div", null), external_react_default.a.createElement("div", null));
}

function Header(_ref2) {
  var currentPage = _ref2.currentPage;

  var _useState = Object(external_react_["useState"])(false),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      show = _useState2[0],
      setShow = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(true),
      _useState4 = Object(slicedToArray["a" /* default */])(_useState3, 2),
      portfolio = _useState4[0],
      setPortfolio = _useState4[1];

  function screenTest(e) {
    e.matches ? setShow(true) : setShow(false);
  }

  Object(external_react_["useEffect"])(function () {
    var width = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);

    if (width >= 993) {
      setShow(true);
      setPortfolio(true);
    }

    var mql = window.matchMedia('(min-width: 992px)');
    mql.addListener(screenTest);
    return function () {
      return mql.removeListener(screenTest);
    };
  });
  return external_react_default.a.createElement(StyledHeader, null, show && external_react_default.a.createElement(MenuItems, null), !show && external_react_default.a.createElement(StyledActiveMenuItem, null, currentPage), portfolio && external_react_default.a.createElement(StyledPortfolio, null, "Portfolio of Sushant"), external_react_default.a.createElement(MenuIcon, {
    show: show,
    setShow: setShow,
    portfolio: portfolio,
    setPortfolio: setPortfolio
  }));

  function MenuItems() {
    return external_react_default.a.createElement(StyledMenuItems, null, external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/"
    }, XAnchor('Home'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/about"
    }, XAnchor('About'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/contact"
    }, XAnchor('Contact'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/resume"
    }, XAnchor('Resume'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/skillset"
    }, XAnchor('Skillset'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/academics"
    }, XAnchor('Academics'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/projects"
    }, XAnchor('Projects'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/qa"
    }, XAnchor('QA'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/blogs",
      as: "/blogs"
    }, XAnchor('Blogs'))));

    function XAnchor(x) {
      return external_react_default.a.createElement("a", {
        style: {
          color: "".concat(getColor(x))
        },
        onClick: function onClick() {
          setShow(false);
          setPortfolio(true);
        }
      }, x);
    }

    function getColor(x) {
      if (x.toLowerCase() === currentPage.toLowerCase()) {
        return 'aquamarine';
      } else {
        return 'white';
      }
    }
  }
}

/* harmony default export */ var header = (Header);
/*

*/
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// EXTERNAL MODULE: ./settings.json
var settings = __webpack_require__("j4ok");

// CONCATENATED MODULE: ./components/footer.tsx






function Footer() {
  var _useState = Object(external_react_["useState"])(0),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      hitCount = _useState2[0],
      setHitCount = _useState2[1];

  Object(external_react_["useEffect"])(function () {
    external_axios_default.a.get(settings.hitCountUrl).then(function (res) {
      hitCount = res.data.hits;
      setHitCount(hitCount);
    });
  }, []);
  return external_react_default.a.createElement(StyledFooter, null, "Hits:", hitCount);
}

var StyledFooter = external_styled_components_default.a.div.withConfig({
  displayName: "footer__StyledFooter",
  componentId: "ol09bi-0"
})(["font-size:0.8rem;text-align:right;"]);
/* harmony default export */ var footer = (Footer);
/*
 ; (async () => {
            const res = await axios.get(settings.hitCountUrl)
            hitCount = res.data.hits
            setHitCount(hitCount)
        })()
*/
// EXTERNAL MODULE: external "react-markdown/with-html"
var with_html_ = __webpack_require__("Q25H");
var with_html_default = /*#__PURE__*/__webpack_require__.n(with_html_);

// CONCATENATED MODULE: ./components/layout.tsx






function Layout(_ref) {
  var _ref$currentPage = _ref.currentPage,
      currentPage = _ref$currentPage === void 0 ? '' : _ref$currentPage,
      _ref$content = _ref.content,
      content = _ref$content === void 0 ? '' : _ref$content,
      _ref$children = _ref.children,
      children = _ref$children === void 0 ? '' : _ref$children,
      _ref$isBanner = _ref.isBanner,
      isBanner = _ref$isBanner === void 0 ? false : _ref$isBanner;
  return external_react_default.a.createElement(StyledLayout, null, external_react_default.a.createElement(header, {
    currentPage: currentPage
  }, "Home"), isBanner && external_react_default.a.createElement(StyledBanner, {
    src: "/static/images/banner1.jpg",
    alt: "banner image"
  }), external_react_default.a.createElement(StyledLeft, null, external_react_default.a.createElement(ProfileImage, {
    src: "/static/images/sush4.jpg",
    alt: "Image of Sushant Agrawal"
  }), external_react_default.a.createElement(ProfileText, null, "Sushant Agrawal", external_react_default.a.createElement(StyledH5, null, "Full stack software developer"))), external_react_default.a.createElement(StyledRight, null), external_react_default.a.createElement(XMain, {
    content: content,
    children: children
  }));
}

function XMain(_ref2) {
  var content = _ref2.content,
      children = _ref2.children;
  var ret;

  if (content && children) {
    ret = external_react_default.a.createElement(StyledMain, null, external_react_default.a.createElement(with_html_default.a, {
      escapeHtml: false,
      source: content
    }), external_react_default.a.createElement(StyledMain, null, children), external_react_default.a.createElement(footer, null));
  } else {
    ret = external_react_default.a.createElement(StyledMain, null, children, external_react_default.a.createElement(footer, null));
  }

  return ret;
}

var StyledLayout = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledLayout",
  componentId: "sc-1l31jg4-0"
})(["display:grid;min-height:calc(100vh - 3px);@media(max-width:500px){grid-template-areas:'header' 'main' 'left';grid-auto-rows:min-content auto auto;}@media only screen and (min-width:501px) and (max-width:992px){grid-template-areas:'header header' 'banner banner' 'main right' 'left right';grid-auto-rows:min-content 100px auto auto;grid-template-columns:auto minmax(10%,20%);}@media only screen and (min-width:993px) and (max-width:1200px){grid-template-areas:'header header header' 'banner banner banner' 'left main right';grid-template-columns:16% auto 25%;grid-template-rows:58px 200px auto;}@media only screen and (min-width:1201px) and (max-width:1500px){grid-template-areas:'header header header' 'banner banner banner' 'left main right';grid-template-columns:16% auto 30%;grid-template-rows:58px minmax(0,200px) auto;}@media only screen and (min-width:1501px){grid-template-areas:'header header header' 'banner banner banner' 'left main right';grid-template-columns:16% auto 43%;grid-template-rows:58px min-content auto;}"]);
var StyledBanner = external_styled_components_default.a.img.withConfig({
  displayName: "layout__StyledBanner",
  componentId: "sc-1l31jg4-1"
})(["grid-area:banner;width:100%;@media(max-width:500px){display:none;}"]);
var StyledRight = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledRight",
  componentId: "sc-1l31jg4-2"
})(["grid-area:right;background-color:#fff;;@media(max-width:992px){display:none;}"]);
var StyledMain = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledMain",
  componentId: "sc-1l31jg4-3"
})(["grid-area:main;background-color:#fff;line-height:2rem;font-size:1.2rem;font-family:'Gill Sans','Gill Sans MT',Calibri,'Trebuchet MS','sans-serif';margin-left:2rem;margin-right:2.3rem;text-align:justify;"]);
var ProfileImage = external_styled_components_default.a.img.withConfig({
  displayName: "layout__ProfileImage",
  componentId: "sc-1l31jg4-4"
})(["display:block;margin:auto;padding-top:2rem;"]);
var ProfileText = external_styled_components_default.a.div.withConfig({
  displayName: "layout__ProfileText",
  componentId: "sc-1l31jg4-5"
})(["text-align:center;"]);
var StyledLeft = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledLeft",
  componentId: "sc-1l31jg4-6"
})(["grid-area:left;background-color:#fff;"]);
var StyledH5 = external_styled_components_default.a.h5.withConfig({
  displayName: "layout__StyledH5",
  componentId: "sc-1l31jg4-7"
})(["color:maroon;font-size:0.8rem;margin:0;"]);
/* harmony default export */ var layout = __webpack_exports__["a"] = (Layout);
/*

*/

/***/ }),

/***/ "9Jkg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("fozc");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "Dtiu":
/***/ (function(module, exports) {

module.exports = require("styled-components");

/***/ }),

/***/ "FbiP":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Gf4D");

/***/ }),

/***/ "Gf4D":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/freeze");

/***/ }),

/***/ "J3/a":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/get-iterator");

/***/ }),

/***/ "K47E":
/***/ (function(module, exports) {

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

module.exports = _assertThisInitialized;

/***/ }),

/***/ "KI45":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "N9n2":
/***/ (function(module, exports, __webpack_require__) {

var _Object$create = __webpack_require__("SqZg");

var setPrototypeOf = __webpack_require__("vjea");

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _Object$create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}

module.exports = _inherits;

/***/ }),

/***/ "O40h":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _asyncToGenerator; });
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eVuF");
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_promise__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "OlXl":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/regenerator/index.js
var regenerator = __webpack_require__("ln6h");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("O40h");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./handy/globalStyle.tsx + 1 modules
var globalStyle = __webpack_require__("OtOE");

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// EXTERNAL MODULE: ./components/head.js
var head = __webpack_require__("tXcZ");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__("wy2R");
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);

// CONCATENATED MODULE: ./components/blogs.tsx






function Blogs(_ref) {
  var blogs = _ref.blogs;
  return external_react_default.a.createElement("div", null, external_react_default.a.createElement("h3", null, "Blogs by Sushant"), keys_default()(blogs).map(function (cat, index) {
    return external_react_default.a.createElement("div", {
      key: index
    }, external_react_default.a.createElement(Styledcat, {
      style: {
        textTransform: 'capitalize'
      }
    }, cat), blogs[cat].sort(function (b, a) {
      return a.createdOn.valueOf() - b.createdOn.valueOf();
    }).map(function (obj, index) {
      var content = obj.content.replace(/[\[\]#]+/g, ''); //remove all occurance of '#'

      return external_react_default.a.createElement(StyledDiv, {
        key: index
      }, external_react_default.a.createElement(link_default.a, {
        href: "/blog/".concat(obj.slug)
      }, external_react_default.a.createElement("a", null, "".concat(obj.title, ": "))), external_react_default.a.createElement(StyledDate, null, "".concat(external_moment_default()(obj.createdOn).format('YYYY, Do MMM'))), external_react_default.a.createElement("br", null), external_react_default.a.createElement(StyledShortContent, null, content + '...'), external_react_default.a.createElement(link_default.a, {
        href: "/blog/".concat(obj.slug)
      }, external_react_default.a.createElement("a", null, '  ', "Read more... ")));
    }));
  }));
}

var StyledDiv = external_styled_components_default.a.div.withConfig({
  displayName: "blogs__StyledDiv",
  componentId: "woin9j-0"
})(["line-height:1.5rem;font-size:1rem;margin-left:1rem;a{font-weight:bold;color:blue;display:inline;text-decoration:none;:active{color:red;}:hover{color:red;}}"]);
var Styledcat = external_styled_components_default.a.div.withConfig({
  displayName: "blogs__Styledcat",
  componentId: "woin9j-1"
})(["color:black;margin:0;font-weight:bold;"]);
var StyledDate = external_styled_components_default.a.span.withConfig({
  displayName: "blogs__StyledDate",
  componentId: "woin9j-2"
})(["color:darkorange;"]);
var StyledShortContent = external_styled_components_default.a.span.withConfig({
  displayName: "blogs__StyledShortContent",
  componentId: "woin9j-3"
})(["color:darkmagenta;"]);
/* harmony default export */ var components_blogs = (Blogs);
// EXTERNAL MODULE: ./components/layout.tsx + 2 modules
var layout = __webpack_require__("5M6V");

// CONCATENATED MODULE: ./pages/blogs.tsx









function BlogsPage(_ref) {
  var blogs = _ref.blogs,
      slug = _ref.slug;
  return external_react_default.a.createElement("div", null, external_react_default.a.createElement(globalStyle["a" /* default */], null), external_react_default.a.createElement(head["a" /* default */], {
    title: "Blogs by Sushant Agrawal, full stack software consultant"
  }), external_react_default.a.createElement(layout["a" /* default */], {
    currentPage: slug
  }, external_react_default.a.createElement(components_blogs, {
    blogs: blogs
  })));
}

BlogsPage.getInitialProps =
/*#__PURE__*/
function () {
  var _ref3 = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(_ref2) {
    var req, res, isServer, blogs, d, slug;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            req = _ref2.req, res = _ref2.res;
            _context.prev = 1;
            isServer = !!req;

            if (!isServer) {
              _context.next = 7;
              break;
            }

            blogs = res.locals.blogs;
            _context.next = 11;
            break;

          case 7:
            _context.next = 9;
            return external_axios_default.a.get('/blogs?client=true');

          case 9:
            d = _context.sent;
            blogs = d.data;

          case 11:
            slug = 'blogs';
            return _context.abrupt("return", {
              blogs: blogs,
              slug: slug
            });

          case 15:
            _context.prev = 15;
            _context.t0 = _context["catch"](1);
            console.log(_context.t0);

          case 18:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[1, 15]]);
  }));

  return function (_x) {
    return _ref3.apply(this, arguments);
  };
}();

/* harmony default export */ var pages_blogs = __webpack_exports__["default"] = (BlogsPage);

/***/ }),

/***/ "OtOE":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js
var define_properties = __webpack_require__("2Eek");
var define_properties_default = /*#__PURE__*/__webpack_require__.n(define_properties);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/freeze.js
var freeze = __webpack_require__("FbiP");
var freeze_default = /*#__PURE__*/__webpack_require__.n(freeze);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/taggedTemplateLiteral.js


function _taggedTemplateLiteral(strings, raw) {
  if (!raw) {
    raw = strings.slice(0);
  }

  return freeze_default()(define_properties_default()(strings, {
    raw: {
      value: freeze_default()(raw)
    }
  }));
}
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");

// CONCATENATED MODULE: ./handy/globalStyle.tsx


function _templateObject() {
  var data = _taggedTemplateLiteral(["\nbody {\n  margin:1px;\n }\n\n* {\n  box-sizing: border-box;\n}\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}


var GlobalStyle = Object(external_styled_components_["createGlobalStyle"])(_templateObject());
/* harmony default export */ var globalStyle = __webpack_exports__["a"] = (GlobalStyle);

/***/ }),

/***/ "Q25H":
/***/ (function(module, exports) {

module.exports = require("react-markdown/with-html");

/***/ }),

/***/ "R2Q7":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/array/is-array");

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "WaGi":
/***/ (function(module, exports, __webpack_require__) {

var _Object$defineProperty = __webpack_require__("hfKm");

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _Object$defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "XXOK":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("J3/a");

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "ZDA2":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("iZP3");

var assertThisInitialized = __webpack_require__("K47E");

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}

module.exports = _possibleConstructorReturn;

/***/ }),

/***/ "aC71":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "bzos":
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/* global __NEXT_DATA__ */

var _interopRequireDefault = __webpack_require__("KI45");

var _stringify = _interopRequireDefault(__webpack_require__("9Jkg"));

var _classCallCheck2 = _interopRequireDefault(__webpack_require__("/HRN"));

var _createClass2 = _interopRequireDefault(__webpack_require__("WaGi"));

var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__("ZDA2"));

var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__("/+P4"));

var _inherits2 = _interopRequireDefault(__webpack_require__("N9n2"));

var __importStar = void 0 && (void 0).__importStar || function (mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) {
    if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
  }
  result["default"] = mod;
  return result;
};

var __importDefault = void 0 && (void 0).__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

var url_1 = __webpack_require__("bzos");

var react_1 = __importStar(__webpack_require__("cDcd"));

var prop_types_1 = __importDefault(__webpack_require__("rf6O"));

var router_1 = __importStar(__webpack_require__("4Q3z"));

var utils_1 = __webpack_require__("p8BD");

function isLocal(href) {
  var url = url_1.parse(href, false, true);
  var origin = url_1.parse(utils_1.getLocationOrigin(), false, true);
  return !url.host || url.protocol === origin.protocol && url.host === origin.host;
}

function memoizedFormatUrl(formatFunc) {
  var lastHref = null;
  var lastAs = null;
  var lastResult = null;
  return function (href, as) {
    if (href === lastHref && as === lastAs) {
      return lastResult;
    }

    var result = formatFunc(href, as);
    lastHref = href;
    lastAs = as;
    lastResult = result;
    return result;
  };
}

function formatUrl(url) {
  return url && typeof url === 'object' ? utils_1.formatWithValidation(url) : url;
}

var Link =
/*#__PURE__*/
function (_react_1$Component) {
  (0, _inherits2.default)(Link, _react_1$Component);

  function Link() {
    var _this;

    (0, _classCallCheck2.default)(this, Link);
    _this = (0, _possibleConstructorReturn2.default)(this, (0, _getPrototypeOf2.default)(Link).apply(this, arguments)); // The function is memoized so that no extra lifecycles are needed
    // as per https://reactjs.org/blog/2018/06/07/you-probably-dont-need-derived-state.html

    _this.formatUrls = memoizedFormatUrl(function (href, asHref) {
      return {
        href: formatUrl(href),
        as: formatUrl(asHref, true)
      };
    });

    _this.linkClicked = function (e) {
      var _e$currentTarget = e.currentTarget,
          nodeName = _e$currentTarget.nodeName,
          target = _e$currentTarget.target;

      if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
        // ignore click for new tab / new window behavior
        return;
      }

      var _this$formatUrls = _this.formatUrls(_this.props.href, _this.props.as),
          href = _this$formatUrls.href,
          as = _this$formatUrls.as;

      if (!isLocal(href)) {
        // ignore click if it's outside our scope
        return;
      }

      var pathname = window.location.pathname;
      href = url_1.resolve(pathname, href);
      as = as ? url_1.resolve(pathname, as) : href;
      e.preventDefault(); //  avoid scroll for urls with anchor refs

      var scroll = _this.props.scroll;

      if (scroll == null) {
        scroll = as.indexOf('#') < 0;
      } // replace state instead of push if prop is present


      router_1.default[_this.props.replace ? 'replace' : 'push'](href, as, {
        shallow: _this.props.shallow
      }).then(function (success) {
        if (!success) return;

        if (scroll) {
          window.scrollTo(0, 0);
          document.body.focus();
        }
      }).catch(function (err) {
        if (_this.props.onError) _this.props.onError(err);
      });
    };

    return _this;
  }

  (0, _createClass2.default)(Link, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.prefetch();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if ((0, _stringify.default)(this.props.href) !== (0, _stringify.default)(prevProps.href)) {
        this.prefetch();
      }
    }
  }, {
    key: "prefetch",
    value: function prefetch() {
      if (!this.props.prefetch) return;
      if (typeof window === 'undefined') return; // Prefetch the JSON page if asked (only in the client)

      var pathname = window.location.pathname;

      var _this$formatUrls2 = this.formatUrls(this.props.href, this.props.as),
          parsedHref = _this$formatUrls2.href;

      var href = url_1.resolve(pathname, parsedHref);
      router_1.default.prefetch(href);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var children = this.props.children;

      var _this$formatUrls3 = this.formatUrls(this.props.href, this.props.as),
          href = _this$formatUrls3.href,
          as = _this$formatUrls3.as; // Deprecated. Warning shown by propType check. If the childen provided is a string (<Link>example</Link>) we wrap it in an <a> tag


      if (typeof children === 'string') {
        children = react_1.default.createElement("a", null, children);
      } // This will return the first child, if multiple are provided it will throw an error


      var child = react_1.Children.only(children);
      var props = {
        onClick: function onClick(e) {
          if (child.props && typeof child.props.onClick === 'function') {
            child.props.onClick(e);
          }

          if (!e.defaultPrevented) {
            _this2.linkClicked(e);
          }
        }
      }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
      // defined, we specify the current 'href', so that repetition is not needed by the user

      if (this.props.passHref || child.type === 'a' && !('href' in child.props)) {
        props.href = as || href;
      } // Add the ending slash to the paths. So, we can serve the
      // "<page>/index.html" directly.


      if (true) {
        if (props.href && typeof __NEXT_DATA__ !== 'undefined' && __NEXT_DATA__.nextExport) {
          props.href = router_1.Router._rewriteUrlForNextExport(props.href);
        }
      }

      return react_1.default.cloneElement(child, props);
    }
  }]);
  return Link;
}(react_1.Component);

if (false) { var exact, warn; }

exports.default = Link;

/***/ }),

/***/ "cu1A":
/***/ (function(module, exports) {

module.exports = require("regenerator-runtime");

/***/ }),

/***/ "doui":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js
var is_array = __webpack_require__("p0XB");
var is_array_default = /*#__PURE__*/__webpack_require__.n(is_array);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithHoles.js

function _arrayWithHoles(arr) {
  if (is_array_default()(arr)) return arr;
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js
var get_iterator = __webpack_require__("XXOK");
var get_iterator_default = /*#__PURE__*/__webpack_require__.n(get_iterator);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArrayLimit.js

function _iterableToArrayLimit(arr, i) {
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = get_iterator_default()(arr), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableRest.js
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance");
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _slicedToArray; });



function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest();
}

/***/ }),

/***/ "eVuF":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aC71");

/***/ }),

/***/ "fozc":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/json/stringify");

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "gXgR":
/***/ (function(module) {

module.exports = {"newCommentId":"id:new-comment","comments":{"submitted":"Your comment is successfully submitted. It will soon appear here after moderation. Your email will not be published.","clickForNewComments":"Click for new comments...","failure":" Your comments could not be submitted due to connectivity problem. Please try again after some time."},"skillset":["Sushant has multiple skills. He is a good learner and can readily pick up what he doesn’t know. He normally takes two to four weeks to pick up new skill.","Having multiple skills in client and server side is particularly useful for full stack development when migration from legacy systems is required. At one time Sushant may be hands on in limited number of skills but having knowledge and low level past working experience in other skills is a boon for executing real time projects.","For skills Sushant is presently not hands-on, he may take around one to two weeks of warm up time. Following table charts up his skill levels, whether he is hands on at present and whether he is interested in coding for that skill. He may have knowledge and past working experience for some items, but he may not be interested in working for that. But the knowledge and experience certainly helps out."],"description":"Sushant can be contacted for full stack software developer in React.js, Node,js, JavaScript, Flutter, React Native, Elasticsearch and PostgreSql"};

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "iZP3":
/***/ (function(module, exports, __webpack_require__) {

var _Symbol$iterator = __webpack_require__("XVgq");

var _Symbol = __webpack_require__("Z7t5");

function _typeof2(obj) { if (typeof _Symbol === "function" && typeof _Symbol$iterator === "symbol") { _typeof2 = function _typeof2(obj) { return typeof obj; }; } else { _typeof2 = function _typeof2(obj) { return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof2(obj); }

function _typeof(obj) {
  if (typeof _Symbol === "function" && _typeof2(_Symbol$iterator) === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return _typeof2(obj);
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : _typeof2(obj);
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "j4ok":
/***/ (function(module) {

module.exports = {"emailHost":"https://chisel.cloudjiffy.net/email","to":"capitalch@gmail.com","subject":"Mail from Sushant Agrawal's profile site","hitCountUrl":"https://chisel.cloudjiffy.net/tools/analytics/hitcount/sushantagrawal.com","token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzaXRlIjoic3VzaGFudGFncmF3YWwuY29tIiwiaWF0IjoxNTYwMDcxOTEwfQ.d89Oe7Qm9bajI2qFlm0h6z1aIky6s3u8PXmcKwPyKfY","commentsUrl":"http://chisel.cloudjiffy.net/tools/comments/sushantagrawal.com"};

/***/ }),

/***/ "ln6h":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cu1A");


/***/ }),

/***/ "ltjX":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-properties");

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p0XB":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("R2Q7");

/***/ }),

/***/ "p8BD":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/utils");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "rf6O":
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "tXcZ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("xnum");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _diction_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("gXgR");
var _diction_json__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t("gXgR", 1);



var defaultDescription = _diction_json__WEBPACK_IMPORTED_MODULE_2__.description; // 'Portfolio of Sushant Agrawal'

var defaultOGURL = 'http://sushantagrawal.com';
var defaultOGImage = 'http://sushantagrawal.com/sushant';
var defaultOGType = 'Portfolio of Sushant Agrawal, full stack software developer';

var Head = function Head(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    charSet: "UTF-8"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("title", null, props.title || ''), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "description",
    content: props.description || defaultDescription
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "viewport",
    content: "width=device-width, initial-scale=1"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "robots",
    content: "index, follow"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "canonical",
    href: "http://www.sushantagrawal.com/"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "icon",
    sizes: "192x192",
    href: "/static/touch-icon.png"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "apple-touch-icon",
    href: "/static/touch-icon.png"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "mask-icon",
    href: "/static/favicon-mask.svg",
    color: "#49B882"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "icon",
    href: "/static/favicon.ico"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:url",
    content: props.url || defaultOGURL
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:title",
    content: props.title || ''
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:description",
    content: props.description || defaultDescription
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "twitter:site",
    content: props.url || defaultOGURL
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "twitter:card",
    content: "summary_large_image"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "twitter:image",
    content: props.ogImage || defaultOGImage
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:image",
    content: props.ogImage || defaultOGImage
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:type",
    content: props.ogType || defaultOGType
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:image:width",
    content: "200"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:image:height",
    content: "300"
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (Head);

/***/ }),

/***/ "vjea":
/***/ (function(module, exports, __webpack_require__) {

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = _Object$setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

module.exports = _setPrototypeOf;

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "wy2R":
/***/ (function(module, exports) {

module.exports = require("moment");

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ })

/******/ });