module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// object to store loaded chunks
/******/ 	// "0" means "already loaded"
/******/ 	var installedChunks = {
/******/ 		"ce6e": 0
/******/ 	};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		var promises = [];
/******/
/******/
/******/ 		// require() chunk loading for javascript
/******/
/******/ 		// "0" is the signal for "already loaded"
/******/ 		if(installedChunks[chunkId] !== 0) {
/******/ 			var chunk = require("../../../" + ({}[chunkId]||chunkId) + "." + {"2ee4":"5b2ce8437032bedfaabe","4a82":"2ece26463fe0c2143205","61f0":"a97f30544ed30c8610bd","62a6":"1be133e36fb283d2309b","b767":"71ad68b5e3db3a85d28c","bb7c":"28f797dd97b4eb754777"}[chunkId] + ".js");
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids;
/******/ 			for(var moduleId in moreModules) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 		}
/******/ 		return Promise.all(promises);
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// uncaught error handler for webpack runtime
/******/ 	__webpack_require__.oe = function(err) {
/******/ 		process.nextTick(function() {
/******/ 			throw err; // catch this error by using import().catch()
/******/ 		});
/******/ 	};
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/+P4":
/***/ (function(module, exports, __webpack_require__) {

var _Object$getPrototypeOf = __webpack_require__("Bhuq");

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = _Object$setPrototypeOf ? _Object$getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || _Object$getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

module.exports = _getPrototypeOf;

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "/HRN":
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ 2:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("23aj");


/***/ }),

/***/ "23aj":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/regenerator/index.js
var regenerator = __webpack_require__("ln6h");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("O40h");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./components/head.js
var head = __webpack_require__("tXcZ");

// EXTERNAL MODULE: ./components/layout.tsx + 2 modules
var layout = __webpack_require__("5M6V");

// EXTERNAL MODULE: ./handy/globalStyle.tsx + 1 modules
var globalStyle = __webpack_require__("OtOE");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__("doui");

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// EXTERNAL MODULE: ./settings.json
var settings = __webpack_require__("j4ok");

// CONCATENATED MODULE: ./components/contact.tsx






function Contact() {
  var _useState = Object(external_react_["useState"])(''),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      name = _useState2[0],
      setName = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(''),
      _useState4 = Object(slicedToArray["a" /* default */])(_useState3, 2),
      mobile = _useState4[0],
      setMobile = _useState4[1];

  var _useState5 = Object(external_react_["useState"])(''),
      _useState6 = Object(slicedToArray["a" /* default */])(_useState5, 2),
      email = _useState6[0],
      setEmail = _useState6[1];

  var _useState7 = Object(external_react_["useState"])(''),
      _useState8 = Object(slicedToArray["a" /* default */])(_useState7, 2),
      message = _useState8[0],
      setMessage = _useState8[1];

  return external_react_default.a.createElement("div", null, external_react_default.a.createElement(AddressDetails, null, external_react_default.a.createElement("h3", null, "Contact details of Sushant"), external_react_default.a.createElement("div", null, " ", contactDetails.address1), external_react_default.a.createElement("div", null, contactDetails.address2), external_react_default.a.createElement("div", null, contactDetails.nearLocation), external_react_default.a.createElement("div", null, contactDetails.district), external_react_default.a.createElement("div", null, contactDetails.pin), external_react_default.a.createElement("div", null, contactDetails.phone), external_react_default.a.createElement("div", null, contactDetails.email)), external_react_default.a.createElement("h4", null, "Directly mail to Sushant"), external_react_default.a.createElement("div", null, external_react_default.a.createElement(Form, {
    onSubmit: sendEmail
  }, external_react_default.a.createElement("div", null, external_react_default.a.createElement("label", null, "Your name: ", external_react_default.a.createElement("span", {
    className: "required"
  }, "*"))), external_react_default.a.createElement("div", null, external_react_default.a.createElement("input", {
    type: "text",
    required: true,
    name: "name",
    value: name,
    onChange: function onChange(e) {
      return setName(e.target.value);
    }
  })), external_react_default.a.createElement("br", null), external_react_default.a.createElement("div", null, external_react_default.a.createElement("label", null, "Your mobile: ", external_react_default.a.createElement("span", {
    className: "required"
  }, "*"))), external_react_default.a.createElement("div", null, external_react_default.a.createElement("input", {
    type: "text",
    pattern: "[0-9]*",
    required: true,
    name: "mobile",
    value: mobile,
    minLength: 10,
    maxLength: 10,
    onChange: function onChange(e) {
      return setMobile(e.target.value);
    }
  })), external_react_default.a.createElement("br", null), external_react_default.a.createElement("div", null, external_react_default.a.createElement("label", null, "Your email: ", external_react_default.a.createElement("span", {
    className: "required"
  }, "*"))), external_react_default.a.createElement("div", null, external_react_default.a.createElement("input", {
    type: "email",
    required: true,
    pattern: "^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$",
    name: "email",
    value: email,
    onChange: function onChange(e) {
      return setEmail(e.target.value);
    }
  })), external_react_default.a.createElement("br", null), external_react_default.a.createElement("div", null, external_react_default.a.createElement("label", null, "Message: ", external_react_default.a.createElement("span", {
    className: "required"
  }, "*"))), external_react_default.a.createElement("div", null, external_react_default.a.createElement("textarea", {
    required: true,
    rows: 6,
    name: "message",
    value: message,
    onChange: function onChange(e) {
      return setMessage(e.target.value);
    }
  })), external_react_default.a.createElement("br", null), external_react_default.a.createElement("div", null, external_react_default.a.createElement("button", {
    type: "submit",
    className: "mailButton"
  }, "Submit")), external_react_default.a.createElement("div", {
    className: "notes"
  }, " Fields marked with ", external_react_default.a.createElement("span", {
    className: "required"
  }, "*"), " are required"))));

  function sendEmail(evt) {
    evt.preventDefault();
    var data = {
      subject: "Message from Sushant Agrawal's profile",
      text: "From: ".concat(email, ",\r\nName: ").concat(name, "\r\nMobile: ").concat(mobile, "\r\nMessage: ").concat(message)
    };
    external_axios_default.a.post(settings.emailHost, data).then(function () {
      return resetForm();
    }).catch(function (err) {
      console.log(err);
    });
  }

  function resetForm() {
    setName("");
    setMobile("");
    setEmail("");
    setMessage("");
  }
}

var AddressDetails = external_styled_components_default.a.div.withConfig({
  displayName: "contact__AddressDetails",
  componentId: "sc-1r9ncrp-0"
})(["margin-top:0.5em;width:100%;"]);
var Form = external_styled_components_default.a.form.withConfig({
  displayName: "contact__Form",
  componentId: "sc-1r9ncrp-1"
})([".required{color:red;}input{width:100%;font-size:1rem;line-height:1.3rem;}textarea{width:100%;font-size:1rem;}.notes{font-size:0.9rem;}"]);
var contactDetails = {
  address1: '92/2A Bidhan Nagar Road',
  address2: '1st floor, Concord towers',
  nearLocation: 'Near Ultadanga More',
  district: 'Kolkata, West bengal, India',
  pin: 'Pin: 700067',
  phone: 'Mobile: +91 8910 322267',
  email: 'Email: capitalch@gmail.com'
};
/* harmony default export */ var contact = (Contact);
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./diction.json
var diction = __webpack_require__("gXgR");

// CONCATENATED MODULE: ./components/skillset.tsx





var skillset_Skillset = function Skillset(_ref) {
  var skills = _ref.skills;
  var runningIndex = 0;

  function Skill(_ref2) {
    var allSkills = _ref2.allSkills,
        skillGroup = _ref2.skillGroup;
    return allSkills[skillGroup].map(function (skill, index) {
      runningIndex++;
      return external_react_default.a.createElement("tr", {
        key: index
      }, external_react_default.a.createElement("td", null, runningIndex), external_react_default.a.createElement("td", null, skill.name), external_react_default.a.createElement("td", null, external_react_default.a.createElement(StyledDiv, {
        style: {
          width: "".concat(skill.level * 10, "%"),
          backgroundColor: "".concat(getColor(skill.level))
        }
      }), external_react_default.a.createElement("span", null, skill.level)), external_react_default.a.createElement("td", {
        className: "media-768"
      }, external_react_default.a.createElement("img", {
        src: skill.handsOn ? '/static/images/yes-20px.png' : '/static/images/no-20px.png'
      })), external_react_default.a.createElement("td", {
        className: "media-768"
      }, external_react_default.a.createElement("img", {
        src: skill.interested ? '/static/images/yes-20px.png' : '/static/images/no-20px.png'
      })), external_react_default.a.createElement("td", {
        className: "media-992"
      }, skill.projects));
    });
  }

  ;

  var skillGroups = keys_default()(skills).map(function (skillGroup, index) {
    return external_react_default.a.createElement(external_react_["Fragment"], {
      key: index
    }, external_react_default.a.createElement("tr", null, external_react_default.a.createElement("th", null), external_react_default.a.createElement("th", {
      colSpan: "5"
    }, skillGroup)), external_react_default.a.createElement(Skill, {
      allSkills: skills,
      skillGroup: skillGroup
    }));
  });

  var Container = external_react_default.a.createElement("div", null, external_react_default.a.createElement(StyledH1, null, "Software development skills of Sushant"), external_react_default.a.createElement(StyledText, null, diction.skillset[0]), external_react_default.a.createElement(StyledText, null, diction.skillset[1]), external_react_default.a.createElement(StyledText, null, diction.skillset[2]), external_react_default.a.createElement("br", null), external_react_default.a.createElement(StyledTable, null, external_react_default.a.createElement("thead", null, external_react_default.a.createElement("tr", null, external_react_default.a.createElement("th", null, "No"), external_react_default.a.createElement("th", null, "Skill name"), external_react_default.a.createElement("th", null, "Skill bar (10 is best)"), external_react_default.a.createElement("th", {
    className: "media-768"
  }, "Hands on"), external_react_default.a.createElement("th", {
    className: "media-768"
  }, "Interested"), external_react_default.a.createElement("th", {
    className: "media-992"
  }, "Experience"))), external_react_default.a.createElement("tbody", null, skillGroups)));
  return Container;
}; // function getRandomColor() {
// 	return 'hsla(' + Math.floor(Math.random() * 360) + ', 100%, 70%, 1)';
// }


function getColor(value) {
  var colorScheme = {
    1: 'grey',
    2: 'yellow',
    3: 'green',
    4: 'blue',
    5: 'black',
    6: 'magenta',
    7: 'cyan',
    8: 'red',
    9: 'violet',
    10: 'red'
  };
  return colorScheme[value];
}

var StyledText = external_styled_components_default.a.div.withConfig({
  displayName: "skillset__StyledText",
  componentId: "d6yc9o-0"
})(["margin-bottom:1rem;font-size:1.2rem;margin-left:1rem;"]);
var StyledH1 = external_styled_components_default.a.h1.withConfig({
  displayName: "skillset__StyledH1",
  componentId: "d6yc9o-1"
})(["font-size:1.4rem;margin-left:1rem;@media(max-width:992px){font-size:1.2rem;}"]);
var StyledTable = external_styled_components_default.a.table.withConfig({
  displayName: "skillset__StyledTable",
  componentId: "d6yc9o-2"
})(["thead{background-color:#dfdfdf;font-size:1.1rem;th{border:1px solid #a0a0a0;}}th{padding-left:0.5rem;padding-right:0.5rem;border:1px solid lightgray;background-color:#f3f3f3;}td{border:1px solid lightgray;padding-left:0.5rem;padding-right:0.5rem;img{display:block;margin:auto;}span{vertical-align:middle;margin-left:0.1rem;}}font-size:1.0rem;border-collapse:collapse;margin-left:1rem;.media-768{@media (max-width:768px){display:none;}}.media-992{@media(max-width:992px){display:none;}}"]);
var StyledDiv = external_styled_components_default.a.div.withConfig({
  displayName: "skillset__StyledDiv",
  componentId: "d6yc9o-3"
})(["display:inline-block;height:10px;border:2px solid yellow;vertical-align:middle;margin-left:0.3rem;"]);
/* harmony default export */ var skillset = (skillset_Skillset);
/*
interface skill {
	w: string;
	b: string;
}
width: ${(props: skill) => props.w + 'px'};
background-color:${(props:skill)=>props.b};
*/
// EXTERNAL MODULE: ./components/comments.tsx + 4 modules
var comments = __webpack_require__("29He");

// CONCATENATED MODULE: ./pages/index.tsx











var slugMapping = {
  home: 'Home for Sushant Agrawal',
  about: 'About Sushant Agrawal',
  contact: 'Contact details of Sushant Agrawal',
  resume: 'Resume of Sushant Agrawal',
  skillset: 'Skillsets of Sushant Agrawal',
  academics: 'Academics of Sushant Agrawal',
  projects: 'Projects done by Sushant Agrawal',
  qa: 'Questions and answers by Sushant Agrawal'
};

var pages_IndexPage = function IndexPage(_ref) {
  var content = _ref.content,
      slug = _ref.slug,
      pageComments = _ref.pageComments,
      skills = _ref.skills;
  return external_react_default.a.createElement("div", null, external_react_default.a.createElement(globalStyle["a" /* default */], null), external_react_default.a.createElement(head["a" /* default */], {
    title: slugMapping[slug]
  }), getPageContent({
    content: content,
    slug: slug,
    pageComments: pageComments,
    skills: skills
  }));
};

pages_IndexPage.getInitialProps =
/*#__PURE__*/
function () {
  var _ref3 = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(_ref2) {
    var res, asPath, slug, content, skills, d, url, params, pageComments;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            res = _ref2.res, asPath = _ref2.asPath;
            slug = asPath.slice(1) || 'home'; // remove first char (/) from asPath

            !allPages[slug] && (slug = 'home');
            _context.t0 = allPages[slug].isMDFile;

            if (!_context.t0) {
              _context.next = 8;
              break;
            }

            _context.next = 7;
            return __webpack_require__("2G8S")("./".concat(slug, ".md"));

          case 7:
            content = _context.sent.default;

          case 8:
            skills = {};

            if (!res) {
              _context.next = 13;
              break;
            }

            if (slug === 'skillset') {
              skills = JSON.parse(res.locals.skills);
            }

            _context.next = 18;
            break;

          case 13:
            if (!(slug === 'skillset')) {
              _context.next = 18;
              break;
            }

            _context.next = 16;
            return external_axios_default.a.get('/skillset?client=true');

          case 16:
            d = _context.sent.data;
            skills = JSON.parse(d.skills);

          case 18:
            url = "".concat(settings.commentsUrl, "/").concat(slug);
            params = {
              token: settings.token
            };
            _context.prev = 20;
            _context.next = 23;
            return external_axios_default.a.get(url, {
              params: params
            });

          case 23:
            pageComments = _context.sent.data;
            _context.next = 29;
            break;

          case 26:
            _context.prev = 26;
            _context.t1 = _context["catch"](20);
            console.log(_context.t1.response && _context.t1.response.data.message || _context.t1.message);

          case 29:
            return _context.abrupt("return", {
              content: content,
              slug: slug,
              pageComments: pageComments,
              skills: skills
            });

          case 30:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[20, 26]]);
  }));

  return function (_x) {
    return _ref3.apply(this, arguments);
  };
}();

function getPageContent(_ref4) {
  var content = _ref4.content,
      slug = _ref4.slug,
      pageComments = _ref4.pageComments,
      skills = _ref4.skills;
  var Ret;

  if (allPages[slug].isMDFile) {
    Ret = external_react_default.a.createElement(layout["a" /* default */], {
      isBanner: allPages[slug].isBanner,
      currentPage: slug,
      content: content
    }, external_react_default.a.createElement(comments["a" /* default */], {
      pageComments: pageComments,
      slug: slug
    }));
  } else {
    Ret = external_react_default.a.createElement(layout["a" /* default */], {
      isBanner: allPages[slug].isBanner,
      currentPage: slug
    }, allPages[slug].component(skills), " ", external_react_default.a.createElement(comments["a" /* default */], {
      pageComments: pageComments,
      slug: slug
    }));
  }

  return Ret;
}

var allPages = {
  home: {
    isBanner: true,
    isMDFile: true
  },
  about: {
    isBanner: true,
    isMDFile: true
  },
  contact: {
    isBanner: true,
    isMDFile: false,
    component: function component() {
      return external_react_default.a.createElement(contact, null);
    }
  },
  resume: {
    isBanner: false,
    isMDFile: true
  },
  skillset: {
    isBanner: false,
    isMDFile: false,
    component: function component(skills) {
      return external_react_default.a.createElement(skillset, {
        skills: skills
      });
    }
  },
  academics: {
    isBanner: false,
    isMDFile: true
  },
  projects: {
    isBanner: false,
    isMDFile: true
  },
  qa: {
    isBanner: false,
    isMDFile: true //,
    // blogs: { isBanner: false, isMDFile: false, component: () => <Blogs></Blogs> }

  }
};
/* harmony default export */ var pages = __webpack_exports__["default"] = (pages_IndexPage);
/*

*/

/***/ }),

/***/ "29He":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js + 1 modules
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js
var is_array = __webpack_require__("p0XB");
var is_array_default = /*#__PURE__*/__webpack_require__.n(is_array);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithoutHoles.js

function _arrayWithoutHoles(arr) {
  if (is_array_default()(arr)) {
    for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) {
      arr2[i] = arr[i];
    }

    return arr2;
  }
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/array/from.js
var from = __webpack_require__("d04V");
var from_default = /*#__PURE__*/__webpack_require__.n(from);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/is-iterable.js
var is_iterable = __webpack_require__("yLu3");
var is_iterable_default = /*#__PURE__*/__webpack_require__.n(is_iterable);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArray.js


function _iterableToArray(iter) {
  if (is_iterable_default()(Object(iter)) || Object.prototype.toString.call(iter) === "[object Arguments]") return from_default()(iter);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableSpread.js
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance");
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/toConsumableArray.js



function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread();
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__("doui");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__("wy2R");
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "react-animations"
var external_react_animations_ = __webpack_require__("WGW3");

// EXTERNAL MODULE: ./settings.json
var settings = __webpack_require__("j4ok");

// EXTERNAL MODULE: ./diction.json
var diction = __webpack_require__("gXgR");

// CONCATENATED MODULE: ./components/comments.tsx











function Comments(_ref) {
  var pageComments = _ref.pageComments,
      slug = _ref.slug;

  var _useState = Object(external_react_["useState"])([]),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      arr = _useState2[0],
      setArr = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(-1),
      _useState4 = Object(slicedToArray["a" /* default */])(_useState3, 2),
      index = _useState4[0],
      setIndex = _useState4[1];

  Object(external_react_["useEffect"])(function () {
    setArr(getCommentsArray(pageComments));
  }, [pageComments]);
  return external_react_default.a.createElement("div", null, external_react_default.a.createElement(StyledCommentButton, {
    onClick: function onClick() {
      setRootForm();
    }
  }, diction.comments.clickForNewComments), external_react_default.a.createElement(CommentsCount, null, "Total ", arr.length, " comments"), arr.map(function (x, index) {
    var src = "/static/persons/".concat(Math.floor(Math.random() * Math.floor(150)), ".png");

    if (x.id) {
      return external_react_default.a.createElement(StyledItem, {
        key: index,
        style: {
          marginLeft: "".concat(x.level * 4, "rem")
        }
      }, external_react_default.a.createElement("div", null, external_react_default.a.createElement(StyledPerson, {
        src: src,
        alt: "person"
      }), external_react_default.a.createElement(StyledName, null, x.mname), external_react_default.a.createElement(StyledTime, null, external_moment_default()(x.commented_on).format('lll'))), external_react_default.a.createElement("div", null, x.comment), external_react_default.a.createElement("div", null, external_react_default.a.createElement(StyledCommentButton, {
        onClick: function onClick() {
          setForm(x);
        }
      }, "Reply")));
    } else {
      return external_react_default.a.createElement("div", {
        key: index
      }, x);
    }
  }));

  function setRootForm() {
    if (index !== -1) {
      arr.splice(index, 1);
    }

    index = 0;
    setIndex(index);
    var parentId = null;
    arr.unshift(external_react_default.a.createElement(SubmitForm, {
      startPos: 0,
      props: {
        index: index,
        setIndex: setIndex,
        arr: arr,
        setArr: setArr,
        slug: slug,
        parentId: parentId
      }
    }));
    setArr(_toConsumableArray(arr));
  }

  function setForm(arrayItem) {
    if (index !== -1) {
      arr.splice(index, 1);
    }

    var arrIndex = arr.findIndex(function (value) {
      return value.id === arrayItem.id;
    });
    index = arrIndex + 1;
    setIndex(index);
    var parentId = arrayItem.id;
    arr.splice(index, 0, external_react_default.a.createElement(SubmitForm, {
      startPos: arrayItem.level,
      props: {
        index: index,
        setIndex: setIndex,
        arr: arr,
        setArr: setArr,
        slug: slug,
        parentId: parentId
      }
    }));
    setArr(_toConsumableArray(arr)); //for refresh purpose ...arr is used
  }
}

function getCommentsArray(pageComm) {
  var outArray = [];

  function process(arr, level) {
    arr && arr.length > 0 && arr.forEach(function (x) {
      outArray.push(Object(objectSpread["a" /* default */])({
        level: level
      }, x));
      x.children && x.children.length > 0 && process(x.children, level + 1);
    });
  }

  process(pageComm, 0);
  return outArray;
}

function SubmitForm(_ref2) {
  var startPos = _ref2.startPos,
      props = _ref2.props;

  var _useState5 = Object(external_react_["useState"])(''),
      _useState6 = Object(slicedToArray["a" /* default */])(_useState5, 2),
      comment = _useState6[0],
      setComment = _useState6[1];

  var _useState7 = Object(external_react_["useState"])(''),
      _useState8 = Object(slicedToArray["a" /* default */])(_useState7, 2),
      mname = _useState8[0],
      setMname = _useState8[1];

  var _useState9 = Object(external_react_["useState"])(''),
      _useState10 = Object(slicedToArray["a" /* default */])(_useState9, 2),
      email = _useState10[0],
      setEmail = _useState10[1];

  var _useState11 = Object(external_react_["useState"])(''),
      _useState12 = Object(slicedToArray["a" /* default */])(_useState11, 2),
      webSite = _useState12[0],
      setWebSite = _useState12[1];

  var _useState13 = Object(external_react_["useState"])(null),
      _useState14 = Object(slicedToArray["a" /* default */])(_useState13, 2),
      success = _useState14[0],
      setSuccess = _useState14[1];

  var index = props.index,
      setIndex = props.setIndex,
      arr = props.arr,
      setArr = props.setArr,
      slug = props.slug,
      parentId = props.parentId;

  function newComment(e) {
    e.preventDefault();
    var payload = {
      token: settings.token,
      text: diction.newCommentId,
      values: {
        parentId: parentId,
        mname: mname,
        email: email,
        visitorSite: webSite,
        comment: comment
      }
    };
    external_axios_default.a.post("".concat(settings.commentsUrl, "/").concat(slug), payload).then(function () {
      setSuccess(true);
      setArr(_toConsumableArray(arr));
    }).catch(function (e) {
      setSuccess(false);
      console.log(e.response && e.response.data.message || e.message);
      setArr(_toConsumableArray(arr));
    });
  }

  function cancelComment() {
    if (index !== -1) {
      arr.splice(index, 1); //delete at index
    }

    setIndex(-1);
    setArr(_toConsumableArray(arr)); //refresh
  }

  var styledForm = external_react_default.a.createElement(StyledForm, {
    onSubmit: newComment,
    style: {
      marginLeft: "".concat(startPos * 4 + 4, "rem")
    }
  }, external_react_default.a.createElement("div", null, external_react_default.a.createElement("textarea", {
    required: true,
    rows: 6,
    placeholder: "Give comments",
    name: "comment",
    value: comment,
    onChange: function onChange(e) {
      return setComment(e.target.value);
    }
  })), external_react_default.a.createElement("div", null, external_react_default.a.createElement("input", {
    type: "text",
    required: true,
    placeholder: "Your name",
    name: "mname",
    value: mname,
    onChange: function onChange(e) {
      return setMname(e.target.value);
    }
  })), external_react_default.a.createElement("div", null, external_react_default.a.createElement("input", {
    required: true,
    type: "email",
    pattern: "^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$",
    placeholder: "Your email",
    name: "email",
    value: email,
    onChange: function onChange(e) {
      return setEmail(e.target.value);
    }
  })), external_react_default.a.createElement("div", null, external_react_default.a.createElement("input", {
    type: "text",
    placeholder: "Your web site",
    name: "webSite",
    value: webSite,
    onChange: function onChange(e) {
      return setWebSite(e.target.value);
    }
  })), external_react_default.a.createElement("div", null, external_react_default.a.createElement("button", {
    type: "submit"
  }, "Submit comments"), external_react_default.a.createElement("button", {
    type: "button",
    onClick: function onClick() {
      return cancelComment();
    }
  }, "Cancel comments")));
  var successMessage = external_react_default.a.createElement(StyledMessage, null, "  ", diction.comments.submitted, " ");
  var failureMessage = external_react_default.a.createElement(StyledMessage, null, diction.comments.failure);
  var ret;

  if (success === null || success === undefined) {
    ret = styledForm;
  } else if (success === false) {
    ret = failureMessage;
  } else {
    ret = successMessage;
  }

  return ret; // return success ? successMessage : styledForm
}

var StyledPerson = external_styled_components_default.a.img.withConfig({
  displayName: "comments__StyledPerson",
  componentId: "sc-11n3or9-0"
})(["height:15px;width:15px;margin-right:0.5rem;margin-bottom:-0.1rem;"]);
var CommentsCount = external_styled_components_default.a.span.withConfig({
  displayName: "comments__CommentsCount",
  componentId: "sc-11n3or9-1"
})(["margin-left:1rem;font-size:1.0rem;color:#990033;"]);
var StyledMessage = external_styled_components_default.a.div.withConfig({
  displayName: "comments__StyledMessage",
  componentId: "sc-11n3or9-2"
})(["background-color:#fff;color:black;font-size:1.4rem;font-weight:bold;margin:2rem 0;padding:1rem;background-color:#EEFECF;font-style:italic;border:1px solid red;"]);
var StyledForm = external_styled_components_default.a.form.withConfig({
  displayName: "comments__StyledForm",
  componentId: "sc-11n3or9-3"
})(["animation:2s ", ";width:auto;border:1px solid grey;margin-bottom:1.5rem;margin-top:0.5rem;input,textarea{width:92%;}input{height:2rem;margin:0.5rem 1rem;}textArea{height:6rem;margin:1rem 1rem 0.5rem 1rem;}button{margin:1rem 1rem;cursor:pointer;}"], Object(external_styled_components_["keyframes"])(["", ""], external_react_animations_["rollIn"]));
var StyledName = external_styled_components_default.a.span.withConfig({
  displayName: "comments__StyledName",
  componentId: "sc-11n3or9-4"
})(["color:#336600;margin-right:0.5rem;"]);
var StyledTime = external_styled_components_default.a.span.withConfig({
  displayName: "comments__StyledTime",
  componentId: "sc-11n3or9-5"
})(["font-size:0.9rem;"]);
var StyledCommentButton = external_styled_components_default.a.button.withConfig({
  displayName: "comments__StyledCommentButton",
  componentId: "sc-11n3or9-6"
})(["border:0;background:none;box-shadow:none;border-radius:0px;cursor:pointer;margin:0px;padding:0px;color:blue;:focus{outline:none;}margin-bottom:1rem;margin-top:1rem;"]);
var StyledItem = external_styled_components_default.a.div.withConfig({
  displayName: "comments__StyledItem",
  componentId: "sc-11n3or9-7"
})(["display:flex;flex-direction:column;font-size:1.0rem;"]);
/* harmony default export */ var comments = __webpack_exports__["a"] = (Comments);
/*

*/

/***/ }),

/***/ "2Eek":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("ltjX");

/***/ }),

/***/ "2G8S":
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./about.md": [
		"leMS",
		"61f0"
	],
	"./academics.md": [
		"5m9w",
		"4a82"
	],
	"./home.md": [
		"1fUg",
		"b767"
	],
	"./projects.md": [
		"ppvl",
		"2ee4"
	],
	"./qa.md": [
		"jWSG",
		"bb7c"
	],
	"./resume.md": [
		"BxT1",
		"62a6"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "2G8S";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "5M6V":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__("doui");

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// CONCATENATED MODULE: ./components/header.tsx



 // import axios from 'axios'

var StyledMenuIcon = external_styled_components_default.a.div.withConfig({
  displayName: "header__StyledMenuIcon",
  componentId: "dc1kf3-0"
})(["div{width:35px;height:5px;background-color:#fff;margin:6px 0;}margin:0.5rem;margin-left:2rem;cursor:pointer;@media only screen and (min-width:993px){display:none;}"]);
var StyledMenuItems = external_styled_components_default.a.ul.withConfig({
  displayName: "header__StyledMenuItems",
  componentId: "dc1kf3-1"
})(["display:flex;flex-direction:column;width:60%;a{text-decoration:none;display:block;margin-left:1.3rem;margin-top:0.3rem;margin-bottom:0.3rem;font-size:1.3rem;color:#fff;}li{list-style-type:none;border:1px solid white;border-collapse:collapse;}@media only screen and (min-width:993px){flex-direction:row;align-items:center;li{border:0px;}}.active{color:red;}"]);
var StyledHeader = external_styled_components_default.a.nav.withConfig({
  displayName: "header__StyledHeader",
  componentId: "dc1kf3-2"
})(["grid-area:header;background-color:black;display:flex;justify-content:space-between;"]);
var StyledActiveMenuItem = external_styled_components_default.a.span.withConfig({
  displayName: "header__StyledActiveMenuItem",
  componentId: "dc1kf3-3"
})(["font-weight:700;font-size:1.3rem;margin:auto 1rem;color:#fff;text-transform:capitalize;@media only screen and (min-width:993px){display:none;}"]);
var StyledPortfolio = external_styled_components_default.a.span.withConfig({
  displayName: "header__StyledPortfolio",
  componentId: "dc1kf3-4"
})(["font-size:1rem;font-weight:bold;color:#fff;margin-left:auto;margin-top:auto;margin-bottom:auto;margin-right:0.5rem;"]);

function MenuIcon(_ref) {
  var show = _ref.show,
      setShow = _ref.setShow,
      portfolio = _ref.portfolio,
      setPortfolio = _ref.setPortfolio;
  return external_react_default.a.createElement(StyledMenuIcon, {
    onClick: function onClick() {
      setShow(!show);
      setPortfolio(!portfolio);
    }
  }, external_react_default.a.createElement("div", null), external_react_default.a.createElement("div", null), external_react_default.a.createElement("div", null));
}

function Header(_ref2) {
  var currentPage = _ref2.currentPage;

  var _useState = Object(external_react_["useState"])(false),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      show = _useState2[0],
      setShow = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(true),
      _useState4 = Object(slicedToArray["a" /* default */])(_useState3, 2),
      portfolio = _useState4[0],
      setPortfolio = _useState4[1];

  function screenTest(e) {
    e.matches ? setShow(true) : setShow(false);
  }

  Object(external_react_["useEffect"])(function () {
    var width = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);

    if (width >= 993) {
      setShow(true);
      setPortfolio(true);
    }

    var mql = window.matchMedia('(min-width: 992px)');
    mql.addListener(screenTest);
    return function () {
      return mql.removeListener(screenTest);
    };
  });
  return external_react_default.a.createElement(StyledHeader, null, show && external_react_default.a.createElement(MenuItems, null), !show && external_react_default.a.createElement(StyledActiveMenuItem, null, currentPage), portfolio && external_react_default.a.createElement(StyledPortfolio, null, "Portfolio of Sushant"), external_react_default.a.createElement(MenuIcon, {
    show: show,
    setShow: setShow,
    portfolio: portfolio,
    setPortfolio: setPortfolio
  }));

  function MenuItems() {
    return external_react_default.a.createElement(StyledMenuItems, null, external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/"
    }, XAnchor('Home'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/about"
    }, XAnchor('About'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/contact"
    }, XAnchor('Contact'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/resume"
    }, XAnchor('Resume'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/skillset"
    }, XAnchor('Skillset'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/academics"
    }, XAnchor('Academics'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/projects"
    }, XAnchor('Projects'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/qa"
    }, XAnchor('QA'))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/blogs",
      as: "/blogs"
    }, XAnchor('Blogs'))));

    function XAnchor(x) {
      return external_react_default.a.createElement("a", {
        style: {
          color: "".concat(getColor(x))
        },
        onClick: function onClick() {
          setShow(false);
          setPortfolio(true);
        }
      }, x);
    }

    function getColor(x) {
      if (x.toLowerCase() === currentPage.toLowerCase()) {
        return 'aquamarine';
      } else {
        return 'white';
      }
    }
  }
}

/* harmony default export */ var header = (Header);
/*

*/
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// EXTERNAL MODULE: ./settings.json
var settings = __webpack_require__("j4ok");

// CONCATENATED MODULE: ./components/footer.tsx






function Footer() {
  var _useState = Object(external_react_["useState"])(0),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      hitCount = _useState2[0],
      setHitCount = _useState2[1];

  Object(external_react_["useEffect"])(function () {
    external_axios_default.a.get(settings.hitCountUrl).then(function (res) {
      hitCount = res.data.hits;
      setHitCount(hitCount);
    });
  }, []);
  return external_react_default.a.createElement(StyledFooter, null, "Hits:", hitCount);
}

var StyledFooter = external_styled_components_default.a.div.withConfig({
  displayName: "footer__StyledFooter",
  componentId: "ol09bi-0"
})(["font-size:0.8rem;text-align:right;"]);
/* harmony default export */ var footer = (Footer);
/*
 ; (async () => {
            const res = await axios.get(settings.hitCountUrl)
            hitCount = res.data.hits
            setHitCount(hitCount)
        })()
*/
// EXTERNAL MODULE: external "react-markdown/with-html"
var with_html_ = __webpack_require__("Q25H");
var with_html_default = /*#__PURE__*/__webpack_require__.n(with_html_);

// CONCATENATED MODULE: ./components/layout.tsx






function Layout(_ref) {
  var _ref$currentPage = _ref.currentPage,
      currentPage = _ref$currentPage === void 0 ? '' : _ref$currentPage,
      _ref$content = _ref.content,
      content = _ref$content === void 0 ? '' : _ref$content,
      _ref$children = _ref.children,
      children = _ref$children === void 0 ? '' : _ref$children,
      _ref$isBanner = _ref.isBanner,
      isBanner = _ref$isBanner === void 0 ? false : _ref$isBanner;
  return external_react_default.a.createElement(StyledLayout, null, external_react_default.a.createElement(header, {
    currentPage: currentPage
  }, "Home"), isBanner && external_react_default.a.createElement(StyledBanner, {
    src: "/static/images/banner1.jpg",
    alt: "banner image"
  }), external_react_default.a.createElement(StyledLeft, null, external_react_default.a.createElement(ProfileImage, {
    src: "/static/images/sush4.jpg",
    alt: "Image of Sushant Agrawal"
  }), external_react_default.a.createElement(ProfileText, null, "Sushant Agrawal ", external_react_default.a.createElement("div", null, "capitalch@gmail.com"))), external_react_default.a.createElement(StyledRight, null), external_react_default.a.createElement(XMain, {
    content: content,
    children: children
  }));
}

function XMain(_ref2) {
  var content = _ref2.content,
      children = _ref2.children;
  var ret;

  if (content && children) {
    ret = external_react_default.a.createElement(StyledMain, null, external_react_default.a.createElement(with_html_default.a, {
      escapeHtml: false,
      source: content
    }), external_react_default.a.createElement(StyledMain, null, children), external_react_default.a.createElement(footer, null));
  } else {
    ret = external_react_default.a.createElement(StyledMain, null, children, external_react_default.a.createElement(footer, null));
  }

  return ret;
}

var StyledLayout = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledLayout",
  componentId: "sc-1xm1gx4-0"
})(["display:grid;min-height:calc(100vh - 3px);@media(max-width:500px){grid-template-areas:'header' 'main' 'left';grid-auto-rows:min-content auto auto;}@media only screen and (min-width:501px) and (max-width:992px){grid-template-areas:'header header' 'banner banner' 'main right' 'left right';grid-auto-rows:min-content 100px auto auto;grid-template-columns:auto minmax(10%,20%);}@media only screen and (min-width:993px) and (max-width:1200px){grid-template-areas:'header header header' 'banner banner banner' 'left main right';grid-template-columns:16% auto 25%;grid-template-rows:58px 200px auto;}@media only screen and (min-width:1201px) and (max-width:1500px){grid-template-areas:'header header header' 'banner banner banner' 'left main right';grid-template-columns:16% auto 30%;grid-template-rows:58px minmax(0,200px) auto;}@media only screen and (min-width:1501px){grid-template-areas:'header header header' 'banner banner banner' 'left main right';grid-template-columns:16% auto 43%;grid-template-rows:58px min-content auto;}"]);
var StyledBanner = external_styled_components_default.a.img.withConfig({
  displayName: "layout__StyledBanner",
  componentId: "sc-1xm1gx4-1"
})(["grid-area:banner;width:100%;@media(max-width:500px){display:none;}"]);
var StyledRight = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledRight",
  componentId: "sc-1xm1gx4-2"
})(["grid-area:right;background-color:#fff;;@media(max-width:992px){display:none;}"]);
var StyledMain = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledMain",
  componentId: "sc-1xm1gx4-3"
})(["grid-area:main;background-color:#fff;line-height:2rem;font-size:1.2rem;font-family:'Gill Sans','Gill Sans MT',Calibri,'Trebuchet MS','sans-serif';margin-left:2rem;margin-right:2.3rem;text-align:justify;"]);
var ProfileImage = external_styled_components_default.a.img.withConfig({
  displayName: "layout__ProfileImage",
  componentId: "sc-1xm1gx4-4"
})(["display:block;margin:auto;padding-top:2rem;"]);
var ProfileText = external_styled_components_default.a.div.withConfig({
  displayName: "layout__ProfileText",
  componentId: "sc-1xm1gx4-5"
})(["text-align:center;"]);
var StyledLeft = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledLeft",
  componentId: "sc-1xm1gx4-6"
})(["grid-area:left;background-color:#fff;"]);
/* harmony default export */ var layout = __webpack_exports__["a"] = (Layout);
/*

*/

/***/ }),

/***/ "9Jkg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("fozc");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "Dtiu":
/***/ (function(module, exports) {

module.exports = require("styled-components");

/***/ }),

/***/ "FbiP":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Gf4D");

/***/ }),

/***/ "Gf4D":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/freeze");

/***/ }),

/***/ "J3/a":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/get-iterator");

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K47E":
/***/ (function(module, exports) {

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

module.exports = _assertThisInitialized;

/***/ }),

/***/ "KI45":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "Kjtv":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/is-iterable");

/***/ }),

/***/ "N9n2":
/***/ (function(module, exports, __webpack_require__) {

var _Object$create = __webpack_require__("SqZg");

var setPrototypeOf = __webpack_require__("vjea");

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _Object$create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}

module.exports = _inherits;

/***/ }),

/***/ "O40h":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _asyncToGenerator; });
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eVuF");
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_promise__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "OtOE":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js
var define_properties = __webpack_require__("2Eek");
var define_properties_default = /*#__PURE__*/__webpack_require__.n(define_properties);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/freeze.js
var freeze = __webpack_require__("FbiP");
var freeze_default = /*#__PURE__*/__webpack_require__.n(freeze);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/taggedTemplateLiteral.js


function _taggedTemplateLiteral(strings, raw) {
  if (!raw) {
    raw = strings.slice(0);
  }

  return freeze_default()(define_properties_default()(strings, {
    raw: {
      value: freeze_default()(raw)
    }
  }));
}
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");

// CONCATENATED MODULE: ./handy/globalStyle.tsx


function _templateObject() {
  var data = _taggedTemplateLiteral(["\nbody {\n  margin:1px;\n }\n\n* {\n  box-sizing: border-box;\n}\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}


var GlobalStyle = Object(external_styled_components_["createGlobalStyle"])(_templateObject());
/* harmony default export */ var globalStyle = __webpack_exports__["a"] = (GlobalStyle);

/***/ }),

/***/ "Q25H":
/***/ (function(module, exports) {

module.exports = require("react-markdown/with-html");

/***/ }),

/***/ "R2Q7":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/array/is-array");

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "WGW3":
/***/ (function(module, exports) {

module.exports = require("react-animations");

/***/ }),

/***/ "WaGi":
/***/ (function(module, exports, __webpack_require__) {

var _Object$defineProperty = __webpack_require__("hfKm");

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _Object$defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "XXOK":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("J3/a");

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "ZDA2":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("iZP3");

var assertThisInitialized = __webpack_require__("K47E");

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}

module.exports = _possibleConstructorReturn;

/***/ }),

/***/ "aC71":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "bzos":
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/* global __NEXT_DATA__ */

var _interopRequireDefault = __webpack_require__("KI45");

var _stringify = _interopRequireDefault(__webpack_require__("9Jkg"));

var _classCallCheck2 = _interopRequireDefault(__webpack_require__("/HRN"));

var _createClass2 = _interopRequireDefault(__webpack_require__("WaGi"));

var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__("ZDA2"));

var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__("/+P4"));

var _inherits2 = _interopRequireDefault(__webpack_require__("N9n2"));

var __importStar = void 0 && (void 0).__importStar || function (mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) {
    if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
  }
  result["default"] = mod;
  return result;
};

var __importDefault = void 0 && (void 0).__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

var url_1 = __webpack_require__("bzos");

var react_1 = __importStar(__webpack_require__("cDcd"));

var prop_types_1 = __importDefault(__webpack_require__("rf6O"));

var router_1 = __importStar(__webpack_require__("4Q3z"));

var utils_1 = __webpack_require__("p8BD");

function isLocal(href) {
  var url = url_1.parse(href, false, true);
  var origin = url_1.parse(utils_1.getLocationOrigin(), false, true);
  return !url.host || url.protocol === origin.protocol && url.host === origin.host;
}

function memoizedFormatUrl(formatFunc) {
  var lastHref = null;
  var lastAs = null;
  var lastResult = null;
  return function (href, as) {
    if (href === lastHref && as === lastAs) {
      return lastResult;
    }

    var result = formatFunc(href, as);
    lastHref = href;
    lastAs = as;
    lastResult = result;
    return result;
  };
}

function formatUrl(url) {
  return url && typeof url === 'object' ? utils_1.formatWithValidation(url) : url;
}

var Link =
/*#__PURE__*/
function (_react_1$Component) {
  (0, _inherits2.default)(Link, _react_1$Component);

  function Link() {
    var _this;

    (0, _classCallCheck2.default)(this, Link);
    _this = (0, _possibleConstructorReturn2.default)(this, (0, _getPrototypeOf2.default)(Link).apply(this, arguments)); // The function is memoized so that no extra lifecycles are needed
    // as per https://reactjs.org/blog/2018/06/07/you-probably-dont-need-derived-state.html

    _this.formatUrls = memoizedFormatUrl(function (href, asHref) {
      return {
        href: formatUrl(href),
        as: formatUrl(asHref, true)
      };
    });

    _this.linkClicked = function (e) {
      var _e$currentTarget = e.currentTarget,
          nodeName = _e$currentTarget.nodeName,
          target = _e$currentTarget.target;

      if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
        // ignore click for new tab / new window behavior
        return;
      }

      var _this$formatUrls = _this.formatUrls(_this.props.href, _this.props.as),
          href = _this$formatUrls.href,
          as = _this$formatUrls.as;

      if (!isLocal(href)) {
        // ignore click if it's outside our scope
        return;
      }

      var pathname = window.location.pathname;
      href = url_1.resolve(pathname, href);
      as = as ? url_1.resolve(pathname, as) : href;
      e.preventDefault(); //  avoid scroll for urls with anchor refs

      var scroll = _this.props.scroll;

      if (scroll == null) {
        scroll = as.indexOf('#') < 0;
      } // replace state instead of push if prop is present


      router_1.default[_this.props.replace ? 'replace' : 'push'](href, as, {
        shallow: _this.props.shallow
      }).then(function (success) {
        if (!success) return;

        if (scroll) {
          window.scrollTo(0, 0);
          document.body.focus();
        }
      }).catch(function (err) {
        if (_this.props.onError) _this.props.onError(err);
      });
    };

    return _this;
  }

  (0, _createClass2.default)(Link, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.prefetch();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if ((0, _stringify.default)(this.props.href) !== (0, _stringify.default)(prevProps.href)) {
        this.prefetch();
      }
    }
  }, {
    key: "prefetch",
    value: function prefetch() {
      if (!this.props.prefetch) return;
      if (typeof window === 'undefined') return; // Prefetch the JSON page if asked (only in the client)

      var pathname = window.location.pathname;

      var _this$formatUrls2 = this.formatUrls(this.props.href, this.props.as),
          parsedHref = _this$formatUrls2.href;

      var href = url_1.resolve(pathname, parsedHref);
      router_1.default.prefetch(href);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var children = this.props.children;

      var _this$formatUrls3 = this.formatUrls(this.props.href, this.props.as),
          href = _this$formatUrls3.href,
          as = _this$formatUrls3.as; // Deprecated. Warning shown by propType check. If the childen provided is a string (<Link>example</Link>) we wrap it in an <a> tag


      if (typeof children === 'string') {
        children = react_1.default.createElement("a", null, children);
      } // This will return the first child, if multiple are provided it will throw an error


      var child = react_1.Children.only(children);
      var props = {
        onClick: function onClick(e) {
          if (child.props && typeof child.props.onClick === 'function') {
            child.props.onClick(e);
          }

          if (!e.defaultPrevented) {
            _this2.linkClicked(e);
          }
        }
      }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
      // defined, we specify the current 'href', so that repetition is not needed by the user

      if (this.props.passHref || child.type === 'a' && !('href' in child.props)) {
        props.href = as || href;
      } // Add the ending slash to the paths. So, we can serve the
      // "<page>/index.html" directly.


      if (true) {
        if (props.href && typeof __NEXT_DATA__ !== 'undefined' && __NEXT_DATA__.nextExport) {
          props.href = router_1.Router._rewriteUrlForNextExport(props.href);
        }
      }

      return react_1.default.cloneElement(child, props);
    }
  }]);
  return Link;
}(react_1.Component);

if (false) { var exact, warn; }

exports.default = Link;

/***/ }),

/***/ "cu1A":
/***/ (function(module, exports) {

module.exports = require("regenerator-runtime");

/***/ }),

/***/ "d04V":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("r7XW");

/***/ }),

/***/ "doui":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js
var is_array = __webpack_require__("p0XB");
var is_array_default = /*#__PURE__*/__webpack_require__.n(is_array);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithHoles.js

function _arrayWithHoles(arr) {
  if (is_array_default()(arr)) return arr;
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js
var get_iterator = __webpack_require__("XXOK");
var get_iterator_default = /*#__PURE__*/__webpack_require__.n(get_iterator);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArrayLimit.js

function _iterableToArrayLimit(arr, i) {
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = get_iterator_default()(arr), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableRest.js
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance");
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _slicedToArray; });



function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest();
}

/***/ }),

/***/ "eVuF":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aC71");

/***/ }),

/***/ "fozc":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/json/stringify");

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "gXgR":
/***/ (function(module) {

module.exports = {"newCommentId":"id:new-comment","comments":{"submitted":"Your comment is successfully submitted. It will soon appear here after moderation. Your email will not be published.","clickForNewComments":"Click for new comments...","failure":" Your comments could not be submitted due to connectivity problem. Please try again after some time."},"skillset":["I have multiple skills. I am a good learner and can readily pick up what I don’t know. I normally take two to four weeks to pick up new skill.","Having multiple skills in client and server side is particularly useful for full stack development when migration from legacy systems is required. At one time I may be hands on in limited number of skills but having knowledge and low level past working experience in other skills is a boon for executing real time project.","For skills I am presently not hands-on, I may take around one to two weeks of warm up time. Following table charts up my skill levels, whether I am hands on at present and whether I am interested in coding for that skill. I may have knowledge and past working experience for some items, but I may not be interested in working for that. But the knowledge and experience certainly helps out"],"description":"Personal profile and prortfolio of Sushant Agrawal, a full stack developer in React.js, Node,js, Advanced JavaScript, ES6, Angular, Flutter and PostgreSql. Sushant is having hands on experience in various technologies for over 3 decades"};

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "iZP3":
/***/ (function(module, exports, __webpack_require__) {

var _Symbol$iterator = __webpack_require__("XVgq");

var _Symbol = __webpack_require__("Z7t5");

function _typeof2(obj) { if (typeof _Symbol === "function" && typeof _Symbol$iterator === "symbol") { _typeof2 = function _typeof2(obj) { return typeof obj; }; } else { _typeof2 = function _typeof2(obj) { return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof2(obj); }

function _typeof(obj) {
  if (typeof _Symbol === "function" && _typeof2(_Symbol$iterator) === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return _typeof2(obj);
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : _typeof2(obj);
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "j4ok":
/***/ (function(module) {

module.exports = {"emailHost":"https://chisel.cloudjiffy.net/email","to":"capitalch@gmail.com","subject":"Mail from Sushant Agrawal's profile site","hitCountUrl":"https://chisel.cloudjiffy.net/tools/analytics/hitcount/sushantagrawal.com","token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzaXRlIjoic3VzaGFudGFncmF3YWwuY29tIiwiaWF0IjoxNTYwMDcxOTEwfQ.d89Oe7Qm9bajI2qFlm0h6z1aIky6s3u8PXmcKwPyKfY","commentsUrl":"http://chisel.cloudjiffy.net/tools/comments/sushantagrawal.com"};

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "ln6h":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cu1A");


/***/ }),

/***/ "ltjX":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-properties");

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p0XB":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("R2Q7");

/***/ }),

/***/ "p8BD":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/utils");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "r7XW":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/array/from");

/***/ }),

/***/ "rf6O":
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "tXcZ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("xnum");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _diction_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("gXgR");
var _diction_json__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t("gXgR", 1);



var defaultDescription = _diction_json__WEBPACK_IMPORTED_MODULE_2__.description; // 'Portfolio of Sushant Agrawal'

var defaultOGURL = '';
var defaultOGImage = '';

var Head = function Head(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    charSet: "UTF-8"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("title", null, props.title || ''), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "description",
    content: props.description || defaultDescription
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "viewport",
    content: "width=device-width, initial-scale=1"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "icon",
    sizes: "192x192",
    href: "/static/touch-icon.png"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "apple-touch-icon",
    href: "/static/touch-icon.png"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "mask-icon",
    href: "/static/favicon-mask.svg",
    color: "#49B882"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "icon",
    href: "/static/favicon.ico"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:url",
    content: props.url || defaultOGURL
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:title",
    content: props.title || ''
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:description",
    content: props.description || defaultDescription
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "twitter:site",
    content: props.url || defaultOGURL
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "twitter:card",
    content: "summary_large_image"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "twitter:image",
    content: props.ogImage || defaultOGImage
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:image",
    content: props.ogImage || defaultOGImage
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:image:width",
    content: "1200"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:image:height",
    content: "630"
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (Head);

/***/ }),

/***/ "vjea":
/***/ (function(module, exports, __webpack_require__) {

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = _Object$setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

module.exports = _setPrototypeOf;

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "wy2R":
/***/ (function(module, exports) {

module.exports = require("moment");

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "yLu3":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Kjtv");

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js
var get_own_property_descriptor = __webpack_require__("Jo+v");
var get_own_property_descriptor_default = /*#__PURE__*/__webpack_require__.n(get_own_property_descriptor);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js
var define_property = __webpack_require__("hfKm");
var define_property_default = /*#__PURE__*/__webpack_require__.n(define_property);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js

function _defineProperty(obj, key, value) {
  if (key in obj) {
    define_property_default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = keys_default()(source);

    if (typeof get_own_property_symbols_default.a === 'function') {
      ownKeys = ownKeys.concat(get_own_property_symbols_default()(source).filter(function (sym) {
        return get_own_property_descriptor_default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      _defineProperty(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });