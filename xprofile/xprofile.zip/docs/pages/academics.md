# Academics of Sushant

<table>
    <tr>
        <th>Period</th>
        <th>Institute</th>
        <th>Stream</th>
    </tr>
    <tr>
        <td>1982 - 1986</td>
        <td><a target='_blank' href='https://www.bitmesra.ac.in/'>Birla Institute Of Technology, Mesra</a></td>
        <td> B.Tech (Computer Science). Topped in the branch</td>
    </tr>
    <tr>
        <td>1980 - 1982</td>
        <td><a target='_blank' href='https://www.scottishchurch.ac.in/'>Scottish Church College</a>. (Pure Science) 63.2% marks</td>
        <td>Class 11 + 12</td>
    </tr>
    <tr>
        <td>1976 – 1980</td>
        <td><a target='_blank' href='https://birlahighschool.com/'>Birla High School</a></td>
        <td>Class 6 – Class 10. CBSE score was 80%</td>
    </tr>
    <tr>
        <td>1975</td>
        <td><a target='_blank' href='https://birlahighschool.com/'>Junior Hindi High School</a></td>
        <td>Class 5</td>
    </tr>
    <tr>
        <td>1969 – 1974</td>
        <td><a target='_blank' href='https://abhinavbharati.co.in/'>Abhniv Bharti</a></td>
        <td> Class KG to Class 4. (Montessori)</td>
    </tr>
</table>

I was always good in Alzebra and Science group. I had interest in English and Hindi languages. I can speak Bengali.

My educational certificates are below:
<div><a target='_blank' href='/static/documents/sushant-agrawal-higher-secondary-mark-sheet.pdf'>Higher Secondary mark Sheet</a></div>
<div><a target='_blank' href='/static/documents/susantagrawal_engineering-degree.pdf'>B.Tech. Engineering Degree</a></div>

<style>
    table {
        border-collapse: collapse;
        /* width:90%; */
    }


    td, th {
        border: 1px solid lightGrey;    
        padding: 0.3rem;
        /* margin:1rem; */
    }
    td {
        font-size: 1.0rem;
    }
    p {
        font-size: 1rem;
    }
    h1 {
        font-size: 1.5rem;
    }
</style>