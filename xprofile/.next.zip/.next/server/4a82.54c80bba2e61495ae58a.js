exports.ids = ["4a82"];
exports.modules = {

/***/ "5m9w":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("### Academics of Sushant\r\n\r\n| Period | Institute | Stream  |\r\n| :---  |   :---   |      :----  |\r\n| 1982 - 1986 | Birla Institute Of Technology, Mesra | B.Tech (Computer Science). Topped in the branch  |\r\n| 1980 - 1982 | Scottish Church College | Class 11 + 12. (Pure Science) 63.2% marks  |\r\n| 1976 – 1980 | Birla High School | Class 6 – Class 10. CBSE score was 80% |\r\n| 1975 | Junior Hindi High School | Class 5 |\r\n| 1969 – 1974 | Abhniv Bharti Balmandir | Class KG to Class 4. (Montessori) |\r\n<!-- <table>\r\n<tr>\r\n    <th>Period</th>\r\n    <th>Institute</th>\r\n    <th>Stream</th>\r\n</tr>\r\n<tr>\r\n    <td>1982 - 1986</td>\r\n    <td>Birla Institute Of Technology, Mesra</td>\r\n    <td> B.Tech (Computer Science)</td>\r\n</tr>\r\n<tr>\r\n    <td>1980 - 1982</td>\r\n    <td>Scottish Church College</td>\r\n    <td>Class 11 + 12</td>\r\n</tr>\r\n<tr>\r\n    <td></td>\r\n    <td></td>\r\n    <td></td>\r\n</tr>\r\n<tr>\r\n    <td></td>\r\n    <td></td>\r\n    <td></td>\r\n</tr>\r\n</table> -->\r\n\r\nI was always good in Alzebra and Science group. I had interest in English and Hindi languages. I can also speak Bengali.\r\n\r\nMy educational certificates are below:\r\n<div><a target='_blank' href='/static/documents/sushant-agrawal-higher-secondary-mark-sheet.pdf'>Higher Secondary mark Sheet</a></div>\r\n<div><a target='_blank' href='/static/documents/susantagrawal_engineering-degree.pdf'>B.Tech. Engineering Degree</a></div>\r\n\r\n<style>\r\n    table {\r\n        border-collapse: collapse;\r\n        width:100%;\r\n    }\r\n    td, th {\r\n        border: 1px solid grey;    \r\n        /* padding: 0.5rem; */\r\n        /* margin:1rem; */\r\n    }\r\n    td {\r\n        font-size: 1.0rem;\r\n    }\r\n    p {\r\n        font-size: 1rem;\r\n    }\r\n</style>");

/***/ })

};;