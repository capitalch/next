exports.ids = ["b767"];
exports.modules = {

/***/ "1fUg":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("### Home Sushant\r\n---\r\n\r\n<p>This site is my technical portfolio. I am a software engineer holding B.Tech degree in computer science from BIT, Mesra, india. I do client and server side software development in advanced JavaScript, ES6, React.js, Node.js and PostgreSql database.</p>\r\n\r\nAfter passing out from engineering college I joined my family business. My first mentionable project was to computerize a retail business. Thereafter I developed a service management software to automate repairs and service workflow for authorized service centres. Sometime in year 2006 I joined with my college friend Niraj Tenany to start an offshore development centre in Kolkata, India. In this company I worked as technical hand and did several projects in Microsoft stack and also some work in open source. I am thankful to Niraj for my professional carrier.\r\n\r\nSince year 2017 I mainly worked on open source technology and over the years I developed tremendous confidence in full stack development as invidual contributor and also as team player while developing severals complex softwares in domain of financial accounting, legal, medical and HR. I am hands-on for over 3 decades and posses a success rate of +95%.\r\n\r\nMy dream is to work upon mission critical challenging software projects where I am able to utilize my full power of mind. I can be contacted at capitalch@gmail.com for remote software development work.\r\n\r\n<style> \r\n   \r\n</style>\r\n");

/***/ })

};;