### Home Sushant
---

<p>This site is my technical portfolio. I am a software engineer holding B.Tech degree in computer science from BIT, Mesra, india. I do <span style='color:blue'>full stack</span> (client and server side) software development. I am hands-on with many software development tools and technologies and I wish to do massive development works in years 2019, 2020 and beyond.</p>

After passing out from engineering college I joined my family business. My first mentionable project was to computerize a retail business. Thereafter I developed a service management software to automate repairs and service workflow for authorized service centres. Sometime in year 2006 I joined with my college friend Niraj Tenany to start an offshore development centre in Kolkata, India. In this company I worked as technical hand and did several projects in Microsoft stack and also some work in open source. I am thankful to Niraj for my professional carrier.

Since year 2017 I mainly worked on open source technology and gave effect to many projects in advanced JavaScript, React.js, Flutter mobile and Angular.

Over the years I developed tremendous confidence in full stack development as invidual contributor and also as team player while developing severals complex softwares in domain of financial accounting, legal, medical and HR. I am hands-on for over 3 decades and posses a success rate of +95%. As happens with many experienced people I also have lucrative carrier opportunity for project management but I have chosen to work with hands-on development at low level.

My dream is to work upon mission critical and highly challenging software projects where I am able to utilize my full power of mind. I have time in hand to work on projects of my choice. I can be contacted at capitalch@gmail.com for remote software development work.

<style> 
    p {
        /* font-size: 1.2rem; */
    }
</style>
