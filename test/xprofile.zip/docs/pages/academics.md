### Academics of Sushant

| Period | Institute | Stream | Remarks |
| :---  |   :---   |      :---- | :---- |
| 1982 - 1986 | Birla Institute Of Technology, Mesra | B.Tech (Computer Science) | Topped in the branch |
| 1980 - 1982 | Scottish Church College | Class 11 + 12 | West bengal Board of Higher Secondary Education (Pure Science) 63.2% marks |
| 1976 – 1980 | Birla High School | Class 6 – Class 10 | CBSE score was 80% |
| 1975 | Junior Hindi High School | Class 5 |  |
| 1969 – 1974 | Abhniv Bharti Balmandir | Class KG to Class 4 | Montessori School |


I was always good in Alzebra and Science group. I had interest in English and Hindi languages. I can also speak Bengali.

My educational certificates are below:
<div><a target='_blank' href='/static/documents/sushant-agrawal-higher-secondary-mark-sheet.pdf'>Higher Secondary mark Sheet</a></div>
<div><a target='_blank' href='/static/documents/susantagrawal_engineering-degree.pdf'>B.Tech. Engineering Degree</a></div>

<style>
    table {
        border-collapse: collapse;
    }
    td, th {
        border: 1px solid grey;    
        padding: 0.5rem;
    }
    td {
        font-size: 1.0rem;
    }
    p {
        font-size: 1rem;
    }
</style>