webpackHotUpdate("static\\development\\pages\\index.js",{

/***/ "./components/skillset.tsx":
/*!*********************************!*\
  !*** ./components/skillset.tsx ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _handy_skills_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../handy/skills.json */ "./handy/skills.json");
var _handy_skills_json__WEBPACK_IMPORTED_MODULE_3___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../handy/skills.json */ "./handy/skills.json", 1);
/* harmony import */ var _diction_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../diction.json */ "./diction.json");
var _diction_json__WEBPACK_IMPORTED_MODULE_4___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../diction.json */ "./diction.json", 1);






var Skillset = function Skillset() {
  var runningIndex = 0; // console.log(skills)

  function Skill(_ref) {
    var allSkills = _ref.allSkills,
        skillGroup = _ref.skillGroup;
    return allSkills[skillGroup].map(function (skill, index) {
      runningIndex++;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", {
        key: index
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, runningIndex), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, skill.name), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledDiv, {
        style: {
          width: "".concat(skill.level * 10, "%")
        }
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, skill.level)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
        className: "media-768"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("img", {
        src: skill.handsOn ? '/static/images/yes-20px.png' : '/static/images/no-20px.png'
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
        className: "media-768"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("img", {
        src: skill.interested ? '/static/images/yes-20px.png' : '/static/images/no-20px.png'
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("td", {
        className: "media-992"
      }, skill.projects));
    });
  }

  ;

  var skillGroups = _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(_handy_skills_json__WEBPACK_IMPORTED_MODULE_3__).map(function (skillGroup, index) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], {
      key: index
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
      colSpan: "5"
    }, skillGroup)), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Skill, {
      allSkills: _handy_skills_json__WEBPACK_IMPORTED_MODULE_3__,
      skillGroup: skillGroup
    }));
  });

  var Container = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledH1, null, "Software development skills of Sushant"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledText, null, _diction_json__WEBPACK_IMPORTED_MODULE_4__.skillset[0]), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledText, null, _diction_json__WEBPACK_IMPORTED_MODULE_4__.skillset[1]), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledText, null, _diction_json__WEBPACK_IMPORTED_MODULE_4__.skillset[2]), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledTable, null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tr", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", null, "No"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", null, "Skill name"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", null, "Skill bar (10 is best)"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
    className: "media-768"
  }, "Hands on"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
    className: "media-768"
  }, "Interested"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("th", {
    className: "media-992"
  }, "Experience"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("tbody", null, skillGroups)));
  return Container;
};

function getRandomColor() {
  return 'hsla(' + Math.floor(Math.random() * 360) + ', 100%, 70%, 1)';
}

var StyledText = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].div.withConfig({
  displayName: "skillset__StyledText",
  componentId: "d6yc9o-0"
})(["margin-bottom:1rem;font-size:1.2rem;margin-left:1rem;"]);
var StyledH1 = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].h1.withConfig({
  displayName: "skillset__StyledH1",
  componentId: "d6yc9o-1"
})(["font-size:1.4rem;margin-left:1rem;@media(max-width:992px){font-size:1.2rem;}"]);
var StyledTable = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].table.withConfig({
  displayName: "skillset__StyledTable",
  componentId: "d6yc9o-2"
})(["thead{background-color:#dfdfdf;font-size:1.1rem;th{border:1px solid #a0a0a0;}}th{padding-left:0.5rem;padding-right:0.5rem;border:1px solid lightgray;background-color:#f3f3f3;}td{border:1px solid lightgray;padding-left:0.5rem;padding-right:0.5rem;img{display:block;margin:auto;}span{vertical-align:middle;margin-left:0.1rem;}}font-size:1.0rem;border-collapse:collapse;margin-left:1rem;.media-768{@media (max-width:768px){display:none;}}.media-992{@media(max-width:992px){display:none;}}"]);
var StyledDiv = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].div.withConfig({
  displayName: "skillset__StyledDiv",
  componentId: "d6yc9o-3"
})(["display:inline-block;height:10px;border:2px solid yellow;vertical-align:middle;background-color:", ";margin-left:0.3rem;"], function () {
  return getRandomColor();
});
/* harmony default export */ __webpack_exports__["default"] = (Skillset);
/*
interface skill {
	w: string;
	b: string;
}
width: ${(props: skill) => props.w + 'px'};
background-color:${(props:skill)=>props.b};
*/

/***/ })

})
//# sourceMappingURL=index.js.1df60afae472f9119fb5.hot-update.js.map