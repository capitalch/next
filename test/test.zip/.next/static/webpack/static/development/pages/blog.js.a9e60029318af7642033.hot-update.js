webpackHotUpdate("static\\development\\pages\\blog.js",{

/***/ "./docs/blogs/blog1.md":
/*!*****************************!*\
  !*** ./docs/blogs/blog1.md ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("---\r\ntitle: this is post1 title for the purpose of testing\r\nslug: post1\r\ncategory: general\r\n---\r\n<div style='color:red'>This is html123</div>\r\n\r\n#### Proin eget velit vel mi pulvinar sagittis et nec augue. \r\n\r\n<table class = 'table'>\r\n<tr>\r\n    <td >col1</td>\r\n</tr>\r\n</table>\r\n\r\n<pre><code class=\"language-javascript\">\r\n    // let x=0; \r\n    x++;\r\n    y = x+=1;\r\n    if ( x === y) {\r\n        z = 200;\r\n        z++;\r\n    }\r\n\r\n</code></pre>\r\n\r\n```javascript\r\n    function sayHello (msg, who) {\r\n        return `${who} says: msg`;\r\n    }\r\n    sayHello(\"Hello World\", \"Johnny\");\r\n```\r\n\r\n\r\nCras felis purus, pellentesque et odio vel, dignissim semper mi. Sed non quam elit. Nam id nulla lacus. Vestibulum mollis enim at nibh tincidunt, id accumsan ligula dapibus. Donec sem justo, blandit et nulla sed, tincidunt aliquet neque. Phasellus ultrices et elit in molestie. Morbi tempus ut lacus vel efficitur. Aliquam erat volutpat. Duis pulvinar leo ut purus ullamcorper, nec cursus ligula hendrerit. Duis in diam dapibus, ullamcorper ipsum consectetur, malesuada justo. Vestibulum condimentum odio vitae nibh rutrum dictum.\r\n\r\nDonec et feugiat risus. Aliquam pretium nulla ac neque interdum iaculis. Nullam et posuere mauris. Quisque arcu metus, bibendum non interdum ut, faucibus quis sapien. Phasellus tempus lacinia imperdiet. Vestibulum viverra id odio at scelerisque. In molestie accumsan faucibus. Quisque hendrerit in ipsum et lobortis. Maecenas consectetur dui ornare tincidunt semper. Sed quam augue, vestibulum sit amet ex et, eleifend interdum libero. Nulla id lorem quam. In fermentum felis velit, vitae vestibulum erat consectetur iaculis. Nullam malesuada tincidunt purus, ut auctor odio tincidunt ac. Morbi eu turpis et risus euismod suscipit non ut lorem. Donec vehicula commodo augue id ultrices.\r\n\r\nMorbi dictum urna vitae nulla blandit fermentum. Aliquam lacinia, nisi at facilisis faucibus, lacus nibh aliquam purus, vel rhoncus magna quam at magna. Nunc fermentum tellus ac nisl aliquam vestibulum. Fusce pellentesque felis mi, eu vulputate ligula faucibus non. Duis vel aliquam mi, id mattis justo. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer ut ipsum sed eros pharetra pellentesque. Etiam mattis convallis nisi, sed luctus dolor eleifend at. In condimentum justo lectus, a feugiat felis convallis vel.");

/***/ })

})
//# sourceMappingURL=blog.js.a9e60029318af7642033.hot-update.js.map