webpackHotUpdate("static\\development\\pages\\index.js",{

/***/ "./components/header.tsx":
/*!*******************************!*\
  !*** ./components/header.tsx ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");




var StyledMenuIcon = styled_components__WEBPACK_IMPORTED_MODULE_3__["default"].div.withConfig({
  displayName: "header__StyledMenuIcon",
  componentId: "dc1kf3-0"
})(["div{width:35px;height:5px;background-color:#fff;margin:6px 0;}margin:0.5rem;margin-left:2rem;cursor:pointer;@media only screen and (min-width:993px){display:none;}"]);
var StyledMenuItems = styled_components__WEBPACK_IMPORTED_MODULE_3__["default"].ul.withConfig({
  displayName: "header__StyledMenuItems",
  componentId: "dc1kf3-1"
})(["display:flex;flex-direction:column;width:60%;a{text-decoration:none;display:block;padding:1rem;font-size:1.3rem;color:#fff;}li{list-style-type:none;border:1px solid white;border-collapse:collapse;}@media only screen and (min-width:993px){flex-direction:row;align-items:center;li{border:0px;}}"]);
var StyledHeader = styled_components__WEBPACK_IMPORTED_MODULE_3__["default"].nav.withConfig({
  displayName: "header__StyledHeader",
  componentId: "dc1kf3-2"
})(["grid-area:header;background-color:black;display:flex;"]);
var StyledActiveMenuItem = styled_components__WEBPACK_IMPORTED_MODULE_3__["default"].span.withConfig({
  displayName: "header__StyledActiveMenuItem",
  componentId: "dc1kf3-3"
})(["font-weight:700;font-size:1.3rem;margin:auto 1rem;color:#fff;text-transform:capitalize;@media only screen and (min-width:993px){display:none;}"]);
var StyledText = styled_components__WEBPACK_IMPORTED_MODULE_3__["default"].span.withConfig({
  displayName: "header__StyledText",
  componentId: "dc1kf3-4"
})(["font-size:1rem;font-weight:bold;color:#fff;margin-left:auto;margin-top:auto;margin-bottom:auto;margin-right:0.5rem;"]);

function MenuIcon(_ref) {
  var show = _ref.show,
      setShow = _ref.setShow;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledMenuIcon, {
    onClick: function onClick() {
      return setShow(!show);
    }
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null));
}

function Header(_ref2) {
  var currentPage = _ref2.currentPage;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      _useState2 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState, 2),
      show = _useState2[0],
      setShow = _useState2[1];

  function screenTest(e) {
    e.matches ? setShow(true) : setShow(false);
  }

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    var width = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);

    if (width >= 993) {
      setShow(true);
    }

    var mql = window.matchMedia('(min-width: 992px)');
    mql.addListener(screenTest);
    return function () {
      return mql.removeListener(screenTest);
    };
  });
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledHeader, null, show && react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MenuItems, null), !show && react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledActiveMenuItem, null, currentPage), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledText, null, "Portfolio of Sushant"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MenuIcon, {
    show: show,
    setShow: setShow
  }));

  function MenuItems() {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledMenuItems, null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "/"
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Home"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "/",
      as: "/contact"
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Contact"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "/",
      as: "/resume"
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Resume"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "/",
      as: "/skillset"
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Skillset"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "/",
      as: "/academics"
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Academics"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "/",
      as: "/projects"
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Projects"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "/",
      as: "/qa"
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "QA"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
      href: "/blogs",
      as: "/blogs"
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Blogs"))));
  }
}

/* harmony default export */ __webpack_exports__["default"] = (Header);
/*

*/

/***/ })

})
//# sourceMappingURL=index.js.2d4125c1338b52b1a0df.hot-update.js.map