exports.ids = [0];
exports.modules = {

/***/ "./docs/pages/academics.md":
/*!*********************************!*\
  !*** ./docs/pages/academics.md ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("# Academics of Sushant\r\n\r\n<div>Sushant was always good in Alzebra and Science group. He had interest in English and Hindi languages.</div>\r\n<div>His educational certificates are below:</div>\r\n<div><a href=\"https://sushant2018.files.wordpress.com/2018/05/sushant-agrawal-higher-secondary-mark-sheet.pdf\">Higher Secondary mark Sheet</a>\r\n<a href=\"https://sushant2018.files.wordpress.com/2018/05/susantagrawal_engineering-degree.pdf\">B.Tech. Engineering Degree</a></div>");

/***/ })

};;
//# sourceMappingURL=0.js.map