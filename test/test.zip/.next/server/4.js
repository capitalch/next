exports.ids = [4];
exports.modules = {

/***/ "./docs/pages/resume.md":
/*!******************************!*\
  !*** ./docs/pages/resume.md ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("# Resume of Sushant\r\n\r\n<style>\r\ntd {\r\n    border: 1px solid black;\r\n    font-size:1rem;\r\n}\r\n</style>");

/***/ })

};;
//# sourceMappingURL=4.js.map