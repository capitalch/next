module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/+P4":
/***/ (function(module, exports, __webpack_require__) {

var _Object$getPrototypeOf = __webpack_require__("Bhuq");

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = _Object$setPrototypeOf ? _Object$getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || _Object$getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

module.exports = _getPrototypeOf;

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "/HRN":
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dKBD");


/***/ }),

/***/ "2Eek":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("ltjX");

/***/ }),

/***/ "3mCA":
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./blog1.md": "NZF4",
	"./blog2.md": "o4ym",
	"./blog3.md": "vAnC",
	"./blog4.md": "J00Z",
	"./blog5.md": "BOw7",
	"./blog6.md": "TSx4",
	"./blog7.md": "BXRv"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "3mCA";

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4ugE":
/***/ (function(module, exports) {

module.exports = require("showdown");

/***/ }),

/***/ "5M6V":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__("doui");

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// CONCATENATED MODULE: ./components/header.tsx




var StyledMenuIcon = external_styled_components_default.a.div.withConfig({
  displayName: "header__StyledMenuIcon",
  componentId: "dc1kf3-0"
})(["div{width:35px;height:5px;background-color:#fff;margin:6px 0;}margin:0.5rem;margin-left:2rem;cursor:pointer;@media only screen and (min-width:993px){display:none;}"]);
var StyledMenuItems = external_styled_components_default.a.ul.withConfig({
  displayName: "header__StyledMenuItems",
  componentId: "dc1kf3-1"
})(["display:flex;flex-direction:column;width:60%;a{text-decoration:none;display:block;padding:1rem;font-size:1.3rem;color:#fff;}li{list-style-type:none;border:1px solid white;border-collapse:collapse;}@media only screen and (min-width:993px){flex-direction:row;align-items:center;li{border:0px;}}"]);
var StyledHeader = external_styled_components_default.a.nav.withConfig({
  displayName: "header__StyledHeader",
  componentId: "dc1kf3-2"
})(["grid-area:header;background-color:black;display:flex;"]);
var StyledActiveMenuItem = external_styled_components_default.a.span.withConfig({
  displayName: "header__StyledActiveMenuItem",
  componentId: "dc1kf3-3"
})(["font-weight:700;font-size:1.3rem;margin:auto 1rem;color:#fff;text-transform:capitalize;@media only screen and (min-width:993px){display:none;}"]);
var StyledText = external_styled_components_default.a.span.withConfig({
  displayName: "header__StyledText",
  componentId: "dc1kf3-4"
})(["font-size:1rem;font-weight:bold;color:#fff;margin-left:auto;margin-top:auto;margin-bottom:auto;margin-right:0.5rem;"]);

function MenuIcon(_ref) {
  var show = _ref.show,
      setShow = _ref.setShow;
  return external_react_default.a.createElement(StyledMenuIcon, {
    onClick: function onClick() {
      return setShow(!show);
    }
  }, external_react_default.a.createElement("div", null), external_react_default.a.createElement("div", null), external_react_default.a.createElement("div", null));
}

function Header(_ref2) {
  var currentPage = _ref2.currentPage;

  var _useState = Object(external_react_["useState"])(false),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      show = _useState2[0],
      setShow = _useState2[1];

  function screenTest(e) {
    e.matches ? setShow(true) : setShow(false);
  }

  Object(external_react_["useEffect"])(function () {
    var width = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);

    if (width >= 993) {
      setShow(true);
    }

    var mql = window.matchMedia('(min-width: 992px)');
    mql.addListener(screenTest);
    return function () {
      return mql.removeListener(screenTest);
    };
  });
  return external_react_default.a.createElement(StyledHeader, null, show && external_react_default.a.createElement(MenuItems, null), !show && external_react_default.a.createElement(StyledActiveMenuItem, null, currentPage), external_react_default.a.createElement(StyledText, null, "Portfolio of Sushant"), external_react_default.a.createElement(MenuIcon, {
    show: show,
    setShow: setShow
  }));

  function MenuItems() {
    return external_react_default.a.createElement(StyledMenuItems, null, external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/"
    }, external_react_default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Home"))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/contact"
    }, external_react_default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Contact"))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/resume"
    }, external_react_default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Resume"))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/skillset"
    }, external_react_default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Skillset"))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/academics"
    }, external_react_default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Academics"))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/projects"
    }, external_react_default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Projects"))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/",
      as: "/qa"
    }, external_react_default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "QA"))), external_react_default.a.createElement("li", null, external_react_default.a.createElement(link_default.a, {
      href: "/blogs",
      as: "/blogs"
    }, external_react_default.a.createElement("a", {
      onClick: function onClick() {
        return setShow(false);
      }
    }, "Blogs"))));
  }
}

/* harmony default export */ var header = (Header);
/*

*/
// EXTERNAL MODULE: external "react-markdown/with-html"
var with_html_ = __webpack_require__("Q25H");
var with_html_default = /*#__PURE__*/__webpack_require__.n(with_html_);

// CONCATENATED MODULE: ./components/layout.tsx




var StyledLayout = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledLayout",
  componentId: "sc-1xm1gx4-0"
})(["display:grid;min-height:calc(100vh - 3px);@media(max-width:500px){grid-template-areas:'header' 'main' 'left';grid-auto-rows:min-content auto auto;}@media only screen and (min-width:501px) and (max-width:992px){grid-template-areas:'header header' 'banner banner' 'main right' 'left right';grid-auto-rows:min-content 100px auto auto;grid-template-columns:auto minmax(10%,20%);}@media only screen and (min-width:993px) and (max-width:1200px){grid-template-areas:'header header header' 'banner banner banner' 'left main right';grid-template-columns:16% auto 25%;grid-template-rows:58px 200px auto;}@media only screen and (min-width:1201px) and (max-width:1500px){grid-template-areas:'header header header' 'banner banner banner' 'left main right';grid-template-columns:16% auto 30%;grid-template-rows:58px 200px auto;}@media only screen and (min-width:1501px){grid-template-areas:'header header header' 'banner banner banner' 'left main right';grid-template-columns:16% auto 43%;grid-template-rows:58px 200px auto;}"]);
var StyledBanner = external_styled_components_default.a.img.withConfig({
  displayName: "layout__StyledBanner",
  componentId: "sc-1xm1gx4-1"
})(["grid-area:banner;width:100%;height:100%;@media(max-width:500px){display:none;}"]);
var StyledRight = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledRight",
  componentId: "sc-1xm1gx4-2"
})(["grid-area:right;background-color:#fff;;@media(max-width:992px){display:none;}"]);
var StyledMain = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledMain",
  componentId: "sc-1xm1gx4-3"
})(["grid-area:main;background-color:#fff;line-height:2rem;font-size:1.3rem;font-family:'Gill Sans','Gill Sans MT',Calibri,'Trebuchet MS','sans-serif';padding-left:2rem;padding-right:2.3rem;text-align:justify;"]);
var ProfileImage = external_styled_components_default.a.img.withConfig({
  displayName: "layout__ProfileImage",
  componentId: "sc-1xm1gx4-4"
})(["display:block;margin:auto;padding-top:2rem;"]);
var ProfileText = external_styled_components_default.a.div.withConfig({
  displayName: "layout__ProfileText",
  componentId: "sc-1xm1gx4-5"
})(["text-align:center;"]);
var StyledLeft = external_styled_components_default.a.div.withConfig({
  displayName: "layout__StyledLeft",
  componentId: "sc-1xm1gx4-6"
})(["grid-area:left;background-color:#fff;"]);

function Layout(_ref) {
  var _ref$currentPage = _ref.currentPage,
      currentPage = _ref$currentPage === void 0 ? '' : _ref$currentPage,
      _ref$content = _ref.content,
      content = _ref$content === void 0 ? '' : _ref$content,
      _ref$children = _ref.children,
      children = _ref$children === void 0 ? '' : _ref$children;
  return external_react_default.a.createElement(StyledLayout, null, external_react_default.a.createElement(header, {
    currentPage: currentPage
  }, "Home"), external_react_default.a.createElement(StyledBanner, {
    src: "/static/images/banner1.jpg",
    alt: "banner image"
  }), external_react_default.a.createElement(StyledLeft, null, external_react_default.a.createElement(ProfileImage, {
    src: "/static/images/sush4.jpg",
    alt: "Image of Sushant Agrawal"
  }), external_react_default.a.createElement(ProfileText, null, "Sushant Agrawal ", external_react_default.a.createElement("div", null, "capitalch@gmail.com"))), external_react_default.a.createElement(StyledRight, null), content && external_react_default.a.createElement(StyledMain, null, external_react_default.a.createElement(with_html_default.a, {
    escapeHtml: false,
    source: content
  })), children && external_react_default.a.createElement(StyledMain, null, children));
}

/* harmony default export */ var layout = __webpack_exports__["a"] = (Layout);
/*
*/

/***/ }),

/***/ "9Jkg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("fozc");

/***/ }),

/***/ "BOw7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("---\r\ntitle: this is post5 title\r\nslug: post5\r\ncategory: technical\r\n---\r\nLorem Ips \"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...\"\r\n\"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain...\"\r\n\r\nEtiam consequat orci augue, nec gravida enim consectetur sit amet. Vivamus molestie magna pellentesque felis euismod sollicitudin. Sed rutrum ipsum nec viverra suscipit. Maecenas semper a ante eget cursus. Quisque eget venenatis elit, eget pretium ligula. Mauris ultricies augue nisl, sed blandit libero blandit ut. Praesent iaculis lobortis neque at mollis. Mauris pulvinar varius purus ac auctor. Quisque eros ex, vulputate a ullamcorper sit amet, consectetur eu magna.\r\n\r\nVivamus dapibus eu justo in mattis. Curabitur molestie rutrum mauris id vulputate. Aenean euismod ante dolor, id faucibus nulla aliquam quis. Cras molestie magna ac tincidunt suscipit. Cras viverra, neque non dignissim luctus, diam orci sollicitudin mi, vel vestibulum massa est vel mi. Suspendisse ut eros quis nisi feugiat maximus eu sed lacus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam placerat mi et ullamcorper facilisis.\r\n\r\nProin eget velit vel mi pulvinar sagittis et nec augue. Cras felis purus, pellentesque et odio vel, dignissim semper mi. Sed non quam elit. Nam id nulla lacus. Vestibulum mollis enim at nibh tincidunt, id accumsan ligula dapibus. Donec sem justo, blandit et nulla sed, tincidunt aliquet neque. Phasellus ultrices et elit in molestie. Morbi tempus ut lacus vel efficitur. Aliquam erat volutpat. Duis pulvinar leo ut purus ullamcorper, nec cursus ligula hendrerit. Duis in diam dapibus, ullamcorper ipsum consectetur, malesuada justo. Vestibulum condimentum odio vitae nibh rutrum dictum.\r\n\r\nDonec et feugiat risus. Aliquam pretium nulla ac neque interdum iaculis. Nullam et posuere mauris. Quisque arcu metus, bibendum non interdum ut, faucibus quis sapien. Phasellus tempus lacinia imperdiet. Vestibulum viverra id odio at scelerisque. In molestie accumsan faucibus. Quisque hendrerit in ipsum et lobortis. Maecenas consectetur dui ornare tincidunt semper. Sed quam augue, vestibulum sit amet ex et, eleifend interdum libero. Nulla id lorem quam. In fermentum felis velit, vitae vestibulum erat consectetur iaculis. Nullam malesuada tincidunt purus, ut auctor odio tincidunt ac. Morbi eu turpis et risus euismod suscipit non ut lorem. Donec vehicula commodo augue id ultrices.\r\n\r\nMorbi dictum urna vitae nulla blandit fermentum. Aliquam lacinia, nisi at facilisis faucibus, lacus nibh aliquam purus, vel rhoncus magna quam at magna. Nunc fermentum tellus ac nisl aliquam vestibulum. Fusce pellentesque felis mi, eu vulputate ligula faucibus non. Duis vel aliquam mi, id mattis justo. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer ut ipsum sed eros pharetra pellentesque. Etiam mattis convallis nisi, sed luctus dolor eleifend at. In condimentum justo lectus, a feugiat felis convallis vel.");

/***/ }),

/***/ "BXRv":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("---\r\ntitle: this is post7 title\r\nslug: post7\r\ncategory: general\r\n---\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "Dtiu":
/***/ (function(module, exports) {

module.exports = require("styled-components");

/***/ }),

/***/ "FbiP":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Gf4D");

/***/ }),

/***/ "Gf4D":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/freeze");

/***/ }),

/***/ "J00Z":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("---\r\ntitle: this is post4 title\r\nslug: post4\r\ncategory: general\r\n---\r\nVivamus quis eros at eros faucibus feugiat. Donec aliquet pretium purus tempus laoreet. Fusce lacinia dui pulvinar purus venenatis malesuada. Nulla pulvinar lectus mi, a consequat odio euismod eget. Praesent vestibulum nibh ex, nec semper mi placerat quis. Praesent purus neque, pellentesque at ligula sit amet, ultrices accumsan nisl. Proin accumsan velit in facilisis euismod.\r\n\r\nAliquam condimentum fringilla ipsum, consequat auctor tellus suscipit ac. Suspendisse vulputate erat nisl, et commodo leo laoreet et. Nam cursus tincidunt ex, ac commodo dui ultricies non. Nam imperdiet pretium justo eu ornare. Cras scelerisque sed tortor ac egestas. Vestibulum id aliquam dolor. Vestibulum ut vehicula purus, nec tristique erat. Maecenas dapibus tellus dolor, in pharetra felis tempor id. Aliquam erat volutpat. Curabitur in dolor erat. Integer in aliquet purus.\r\n\r\nVestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Curabitur nulla velit, auctor ut malesuada ut, pretium eu tellus. Quisque molestie erat ac nunc mattis finibus. Fusce nec arcu ligula. Donec volutpat tristique sapien, in suscipit tortor porta nec. Aliquam commodo, risus ut iaculis molestie, justo nunc gravida quam, lobortis pellentesque neque ipsum et purus. Fusce sit amet nisi ac nulla auctor sagittis. Sed elementum, dolor id tempor faucibus, sem mi porttitor nisl, sit amet faucibus nisl justo quis massa.\r\n\r\nIn placerat sed sapien non tristique. Morbi vulputate vel ligula eu pharetra. Fusce viverra, arcu ut dictum dictum, diam magna mollis nulla, nec pulvinar orci justo sit amet mauris. Nulla fringilla semper quam. Phasellus feugiat mauris eget lacinia scelerisque. Nulla varius egestas faucibus. Pellentesque dapibus ex pellentesque tempor facilisis. Praesent id purus nibh. Pellentesque vehicula quis augue ac tincidunt.\r\n\r\nIn sed nisi eget dolor fringilla aliquet sed a nisl. Pellentesque vulputate augue ac arcu scelerisque, non varius orci semper. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec volutpat sed quam et convallis. Sed sed quam leo. Praesent nec nunc malesuada mi fringilla mattis. Nunc et metus augue. Ut sit amet ipsum sit amet risus egestas fringilla. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque egestas blandit sollicitudin. Duis odio urna, vehicula vitae vulputate sit amet, semper id eros. Donec lobortis dictum maximus. Donec pretium tincidunt justo vel pharetra.");

/***/ }),

/***/ "J3/a":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/get-iterator");

/***/ }),

/***/ "K47E":
/***/ (function(module, exports) {

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

module.exports = _assertThisInitialized;

/***/ }),

/***/ "KI45":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "N4Zu":
/***/ (function(module, exports) {

module.exports = require("prismjs");

/***/ }),

/***/ "N9n2":
/***/ (function(module, exports, __webpack_require__) {

var _Object$create = __webpack_require__("SqZg");

var setPrototypeOf = __webpack_require__("vjea");

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _Object$create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}

module.exports = _inherits;

/***/ }),

/***/ "NZF4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("---\r\ntitle: this is post1 title for the purpose of testing\r\nslug: post1\r\ncategory: general\r\n---\r\n<div style='color:red'>This is html123</div>\r\n\r\n#### Proin eget velit vel mi pulvinar sagittis et nec augue. \r\n\r\n<table class = 'table'>\r\n<tr>\r\n    <td >col1</td>\r\n</tr>\r\n</table>\r\n\r\n<pre><code class=\"language-javascript\">\r\n    // let x=0; \r\n    x++;\r\n    y = x+=1;\r\n    if ( x === y) {\r\n        z = 200;\r\n        z++;\r\n    }\r\n\r\n</code></pre>\r\n\r\n```javascript\r\n    function sayHello (msg, who) {\r\n        return `${who} says: msg`;\r\n    }\r\n    sayHello(\"Hello World\", \"Johnny\");\r\n```\r\n\r\n\r\nCras felis purus, pellentesque et odio vel, dignissim semper mi. Sed non quam elit. Nam id nulla lacus. Vestibulum mollis enim at nibh tincidunt, id accumsan ligula dapibus. Donec sem justo, blandit et nulla sed, tincidunt aliquet neque. Phasellus ultrices et elit in molestie. Morbi tempus ut lacus vel efficitur. Aliquam erat volutpat. Duis pulvinar leo ut purus ullamcorper, nec cursus ligula hendrerit. Duis in diam dapibus, ullamcorper ipsum consectetur, malesuada justo. Vestibulum condimentum odio vitae nibh rutrum dictum.\r\n\r\nDonec et feugiat risus. Aliquam pretium nulla ac neque interdum iaculis. Nullam et posuere mauris. Quisque arcu metus, bibendum non interdum ut, faucibus quis sapien. Phasellus tempus lacinia imperdiet. Vestibulum viverra id odio at scelerisque. In molestie accumsan faucibus. Quisque hendrerit in ipsum et lobortis. Maecenas consectetur dui ornare tincidunt semper. Sed quam augue, vestibulum sit amet ex et, eleifend interdum libero. Nulla id lorem quam. In fermentum felis velit, vitae vestibulum erat consectetur iaculis. Nullam malesuada tincidunt purus, ut auctor odio tincidunt ac. Morbi eu turpis et risus euismod suscipit non ut lorem. Donec vehicula commodo augue id ultrices.\r\n\r\nMorbi dictum urna vitae nulla blandit fermentum. Aliquam lacinia, nisi at facilisis faucibus, lacus nibh aliquam purus, vel rhoncus magna quam at magna. Nunc fermentum tellus ac nisl aliquam vestibulum. Fusce pellentesque felis mi, eu vulputate ligula faucibus non. Duis vel aliquam mi, id mattis justo. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer ut ipsum sed eros pharetra pellentesque. Etiam mattis convallis nisi, sed luctus dolor eleifend at. In condimentum justo lectus, a feugiat felis convallis vel.");

/***/ }),

/***/ "O40h":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _asyncToGenerator; });
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eVuF");
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_promise__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "OtOE":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js
var define_properties = __webpack_require__("2Eek");
var define_properties_default = /*#__PURE__*/__webpack_require__.n(define_properties);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/freeze.js
var freeze = __webpack_require__("FbiP");
var freeze_default = /*#__PURE__*/__webpack_require__.n(freeze);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/taggedTemplateLiteral.js


function _taggedTemplateLiteral(strings, raw) {
  if (!raw) {
    raw = strings.slice(0);
  }

  return freeze_default()(define_properties_default()(strings, {
    raw: {
      value: freeze_default()(raw)
    }
  }));
}
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");

// CONCATENATED MODULE: ./handy/globalStyle.tsx


function _templateObject() {
  var data = _taggedTemplateLiteral(["\nbody {\n  margin:1px;\n }\n\n* {\n  box-sizing: border-box;\n}\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}


var GlobalStyle = Object(external_styled_components_["createGlobalStyle"])(_templateObject());
/* harmony default export */ var globalStyle = __webpack_exports__["a"] = (GlobalStyle);

/***/ }),

/***/ "Q25H":
/***/ (function(module, exports) {

module.exports = require("react-markdown/with-html");

/***/ }),

/***/ "R2Q7":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/array/is-array");

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TSx4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("---\r\ntitle: this is post6 title\r\nslug: post6\r\ncategory: mechanical\r\n---\r\n\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "WaGi":
/***/ (function(module, exports, __webpack_require__) {

var _Object$defineProperty = __webpack_require__("hfKm");

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _Object$defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "XXOK":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("J3/a");

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "ZDA2":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("iZP3");

var assertThisInitialized = __webpack_require__("K47E");

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}

module.exports = _possibleConstructorReturn;

/***/ }),

/***/ "aC71":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "bzos":
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/* global __NEXT_DATA__ */

var _interopRequireDefault = __webpack_require__("KI45");

var _stringify = _interopRequireDefault(__webpack_require__("9Jkg"));

var _classCallCheck2 = _interopRequireDefault(__webpack_require__("/HRN"));

var _createClass2 = _interopRequireDefault(__webpack_require__("WaGi"));

var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__("ZDA2"));

var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__("/+P4"));

var _inherits2 = _interopRequireDefault(__webpack_require__("N9n2"));

var __importStar = void 0 && (void 0).__importStar || function (mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) {
    if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
  }
  result["default"] = mod;
  return result;
};

var __importDefault = void 0 && (void 0).__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

var url_1 = __webpack_require__("bzos");

var react_1 = __importStar(__webpack_require__("cDcd"));

var prop_types_1 = __importDefault(__webpack_require__("rf6O"));

var router_1 = __importStar(__webpack_require__("4Q3z"));

var utils_1 = __webpack_require__("p8BD");

function isLocal(href) {
  var url = url_1.parse(href, false, true);
  var origin = url_1.parse(utils_1.getLocationOrigin(), false, true);
  return !url.host || url.protocol === origin.protocol && url.host === origin.host;
}

function memoizedFormatUrl(formatFunc) {
  var lastHref = null;
  var lastAs = null;
  var lastResult = null;
  return function (href, as) {
    if (href === lastHref && as === lastAs) {
      return lastResult;
    }

    var result = formatFunc(href, as);
    lastHref = href;
    lastAs = as;
    lastResult = result;
    return result;
  };
}

function formatUrl(url) {
  return url && typeof url === 'object' ? utils_1.formatWithValidation(url) : url;
}

var Link =
/*#__PURE__*/
function (_react_1$Component) {
  (0, _inherits2.default)(Link, _react_1$Component);

  function Link() {
    var _this;

    (0, _classCallCheck2.default)(this, Link);
    _this = (0, _possibleConstructorReturn2.default)(this, (0, _getPrototypeOf2.default)(Link).apply(this, arguments)); // The function is memoized so that no extra lifecycles are needed
    // as per https://reactjs.org/blog/2018/06/07/you-probably-dont-need-derived-state.html

    _this.formatUrls = memoizedFormatUrl(function (href, asHref) {
      return {
        href: formatUrl(href),
        as: formatUrl(asHref, true)
      };
    });

    _this.linkClicked = function (e) {
      var _e$currentTarget = e.currentTarget,
          nodeName = _e$currentTarget.nodeName,
          target = _e$currentTarget.target;

      if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
        // ignore click for new tab / new window behavior
        return;
      }

      var _this$formatUrls = _this.formatUrls(_this.props.href, _this.props.as),
          href = _this$formatUrls.href,
          as = _this$formatUrls.as;

      if (!isLocal(href)) {
        // ignore click if it's outside our scope
        return;
      }

      var pathname = window.location.pathname;
      href = url_1.resolve(pathname, href);
      as = as ? url_1.resolve(pathname, as) : href;
      e.preventDefault(); //  avoid scroll for urls with anchor refs

      var scroll = _this.props.scroll;

      if (scroll == null) {
        scroll = as.indexOf('#') < 0;
      } // replace state instead of push if prop is present


      router_1.default[_this.props.replace ? 'replace' : 'push'](href, as, {
        shallow: _this.props.shallow
      }).then(function (success) {
        if (!success) return;

        if (scroll) {
          window.scrollTo(0, 0);
          document.body.focus();
        }
      }).catch(function (err) {
        if (_this.props.onError) _this.props.onError(err);
      });
    };

    return _this;
  }

  (0, _createClass2.default)(Link, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.prefetch();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if ((0, _stringify.default)(this.props.href) !== (0, _stringify.default)(prevProps.href)) {
        this.prefetch();
      }
    }
  }, {
    key: "prefetch",
    value: function prefetch() {
      if (!this.props.prefetch) return;
      if (typeof window === 'undefined') return; // Prefetch the JSON page if asked (only in the client)

      var pathname = window.location.pathname;

      var _this$formatUrls2 = this.formatUrls(this.props.href, this.props.as),
          parsedHref = _this$formatUrls2.href;

      var href = url_1.resolve(pathname, parsedHref);
      router_1.default.prefetch(href);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var children = this.props.children;

      var _this$formatUrls3 = this.formatUrls(this.props.href, this.props.as),
          href = _this$formatUrls3.href,
          as = _this$formatUrls3.as; // Deprecated. Warning shown by propType check. If the childen provided is a string (<Link>example</Link>) we wrap it in an <a> tag


      if (typeof children === 'string') {
        children = react_1.default.createElement("a", null, children);
      } // This will return the first child, if multiple are provided it will throw an error


      var child = react_1.Children.only(children);
      var props = {
        onClick: function onClick(e) {
          if (child.props && typeof child.props.onClick === 'function') {
            child.props.onClick(e);
          }

          if (!e.defaultPrevented) {
            _this2.linkClicked(e);
          }
        }
      }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
      // defined, we specify the current 'href', so that repetition is not needed by the user

      if (this.props.passHref || child.type === 'a' && !('href' in child.props)) {
        props.href = as || href;
      } // Add the ending slash to the paths. So, we can serve the
      // "<page>/index.html" directly.


      if (true) {
        if (props.href && typeof __NEXT_DATA__ !== 'undefined' && __NEXT_DATA__.nextExport) {
          props.href = router_1.Router._rewriteUrlForNextExport(props.href);
        }
      }

      return react_1.default.cloneElement(child, props);
    }
  }]);
  return Link;
}(react_1.Component);

if (false) { var exact, warn; }

exports.default = Link;

/***/ }),

/***/ "cu1A":
/***/ (function(module, exports) {

module.exports = require("regenerator-runtime");

/***/ }),

/***/ "dKBD":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ln6h");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("O40h");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _handy_globalStyle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("OtOE");
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("5M6V");
/* harmony import */ var _components_head__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("tXcZ");
/* harmony import */ var showdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("4ugE");
/* harmony import */ var showdown__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(showdown__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var prismjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("N4Zu");
/* harmony import */ var prismjs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(prismjs__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _prism_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("pvgY");
/* harmony import */ var _prism_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_prism_scss__WEBPACK_IMPORTED_MODULE_8__);










function BlogPage(_ref) {
  var content = _ref.content,
      meta = _ref.meta;
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    prismjs__WEBPACK_IMPORTED_MODULE_7___default.a.highlightAll();
  });
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_handy_globalStyle__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], null), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_components_head__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"], {
    title: "Blog"
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_components_layout__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"], null, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h2", null, meta.title), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    dangerouslySetInnerHTML: {
      __html: content
    }
  })));
}

BlogPage.getInitialProps =
/*#__PURE__*/
function () {
  var _ref3 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(_ref2) {
    var asPath, slug, converter, d, content, meta;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            asPath = _ref2.asPath;
            slug = asPath.split('/')[2];
            converter = new showdown__WEBPACK_IMPORTED_MODULE_6___default.a.Converter({
              metadata: true //,
              // extensions: [showdownHighlight]

            });
            _context.next = 5;
            return __webpack_require__("3mCA")("./".concat(slug, ".md"));

          case 5:
            d = _context.sent.default;
            content = converter.makeHtml(d);
            meta = converter.getMetadata();
            return _context.abrupt("return", {
              content: content,
              meta: meta
            });

          case 9:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x) {
    return _ref3.apply(this, arguments);
  };
}();

/* harmony default export */ __webpack_exports__["default"] = (BlogPage);
/*

*/

/***/ }),

/***/ "doui":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js
var is_array = __webpack_require__("p0XB");
var is_array_default = /*#__PURE__*/__webpack_require__.n(is_array);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithHoles.js

function _arrayWithHoles(arr) {
  if (is_array_default()(arr)) return arr;
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js
var get_iterator = __webpack_require__("XXOK");
var get_iterator_default = /*#__PURE__*/__webpack_require__.n(get_iterator);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArrayLimit.js

function _iterableToArrayLimit(arr, i) {
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = get_iterator_default()(arr), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableRest.js
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance");
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _slicedToArray; });



function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest();
}

/***/ }),

/***/ "eVuF":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aC71");

/***/ }),

/***/ "fozc":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/json/stringify");

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "iZP3":
/***/ (function(module, exports, __webpack_require__) {

var _Symbol$iterator = __webpack_require__("XVgq");

var _Symbol = __webpack_require__("Z7t5");

function _typeof2(obj) { if (typeof _Symbol === "function" && typeof _Symbol$iterator === "symbol") { _typeof2 = function _typeof2(obj) { return typeof obj; }; } else { _typeof2 = function _typeof2(obj) { return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof2(obj); }

function _typeof(obj) {
  if (typeof _Symbol === "function" && _typeof2(_Symbol$iterator) === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return _typeof2(obj);
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : _typeof2(obj);
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "ln6h":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cu1A");


/***/ }),

/***/ "ltjX":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-properties");

/***/ }),

/***/ "o4ym":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("---\r\ntitle: this is post2 title\r\ncategory: aechanical\r\nslug: post2\r\n---\r\nIn congue tincidunt nisl, eget vehicula leo mattis in. Sed ante risus, convallis in enim at, pulvinar eleifend dolor. Ut maximus erat non egestas ultricies. Sed laoreet condimentum nunc, a ultricies nunc bibendum non. Duis eu blandit turpis. Sed facilisis ligula lorem, porta dapibus mauris congue dictum. Cras dolor nisl, congue eu dolor id, ultrices tempus ipsum.\r\n\r\nAenean lobortis tincidunt tellus, eu porta nibh rhoncus ut. Fusce eu consectetur lorem. Nullam sed lorem vel sapien euismod accumsan ullamcorper vitae mauris. Donec eget lacus in nulla porttitor mollis. In tincidunt ac justo interdum sollicitudin. Nam dapibus magna non nibh semper efficitur. Nulla facilisi. Maecenas fermentum accumsan elementum. Fusce bibendum ullamcorper ex vel dictum. Quisque nec orci ultricies, consequat massa vitae, rutrum augue. Nulla in elit sit amet mi scelerisque ultricies. Etiam tellus purus, ultricies quis urna at, interdum tempor ligula.\r\n\r\nNunc tristique nunc id eleifend viverra. Nullam a lorem arcu. Sed scelerisque vitae turpis in placerat. Proin consequat elementum sapien, a maximus ligula molestie nec. Quisque et velit purus. Vivamus enim urna, feugiat et magna nec, feugiat facilisis nibh. Pellentesque condimentum blandit feugiat. Fusce porttitor auctor nisl, sit amet pharetra arcu hendrerit quis. Duis tristique, neque vitae congue egestas, libero dolor facilisis urna, at ultrices erat nibh vel enim. Etiam neque libero, congue at finibus sit amet, lobortis ac neque. In fermentum nisl nec orci sodales, consequat commodo erat venenatis. Integer scelerisque dignissim quam, sit amet accumsan lacus. Nunc rutrum lorem id nunc dignissim, ut gravida ipsum accumsan. Duis vel augue ex.\r\n\r\nEtiam maximus quam at odio ornare, et vulputate magna aliquet. Nullam at maximus nulla. Maecenas mattis eros at odio accumsan volutpat vitae in tortor. Praesent suscipit sem porttitor purus varius sagittis. Suspendisse nec metus placerat, interdum dolor id, auctor ligula. Donec dapibus risus quis sagittis vestibulum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eget ex vel metus ullamcorper malesuada. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.");

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p0XB":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("R2Q7");

/***/ }),

/***/ "p8BD":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/utils");

/***/ }),

/***/ "pvgY":
/***/ (function(module, exports) {

module.exports = {
	"token": "_1WP9KD01vFCdCWeyXPjPaA",
	"comment": "_8_s6XlbAkfovRjFzPXzcd",
	"block-comment": "_7Yax7wZazcBlwsDs8Uvwi",
	"prolog": "_1KlqrhfUqU3LEa5Deruytg",
	"doctype": "_3a0bdWqlIiqYQNzyc1W_aP",
	"cdata": "_1A_PeArxT1RktldKgCSQEx",
	"punctuation": "_23G7AJRqTwleD9YzzDybk8",
	"tag": "_1Z38XcJwzYq7EkYyi4pEIY",
	"attr-name": "_1dq4dNzk8SB_tt5gz7k3Vq",
	"namespace": "_2qn7zYZUo-IvY5T_0GKFpA",
	"deleted": "_2iQ5zX6QcCRM7UqxUgLeX_",
	"function-name": "_3cpTGdxSCrcBEQiimU_c9g",
	"boolean": "_3R3r1q4QPw7KyHbCVIE40r",
	"number": "_2Frg8dPzo87lGRgbZZe5BN",
	"function": "_3b5pa3Z_gGXEi5leexeJt0",
	"property": "_17gI2u6jEhf6ypeup_3M2z",
	"class-name": "rnI2ZTFotCDqprNVwT5Q",
	"constant": "_3wtppPWHHmsIJh5t4lWIY7",
	"symbol": "_36AhK9S6LhcXSLW9Qnk9T_",
	"selector": "_Hje_N4H0SfxR89CzEDRh",
	"important": "_1kzMDPuEO0o-5hAkpZR1CX",
	"atrule": "k8fu3HvtoKRwTi9MAnMwl",
	"keyword": "_31-IskiOc-GnTtCXzmOBVb",
	"builtin": "_1plBABkO5gDw68J0WrH7Hb",
	"string": "_1gQGVjr5OIMsQUpaVh8YtV",
	"char": "_1PPannCzGmirx0i99lqEK8",
	"attr-value": "_2BdTdLgEf5RX_zZF-pjmg1",
	"regex": "_22j4ciACQGp23j3wlOQi_i",
	"variable": "_2TPQkIoB31ZKFr6WwR1AMq",
	"operator": "_3qaOxUJx5SUIeyUQY1CfLm",
	"entity": "_3VK9OoBrIoFE53VoBOsGnU",
	"url": "_3U8JqiO9kAuFLgL0TlKFe1",
	"bold": "_2erHasrBIRMBTp7l7GMYTU",
	"italic": "_3hvX3u6FoJP_Sj4-XRmQjh",
	"inserted": "_3jBS2GSiQWicxLoxljla4H"
};

/***/ }),

/***/ "rf6O":
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "tXcZ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("xnum");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


var defaultDescription = 'Portfolio of Sushant Agrawal';
var defaultOGURL = '';
var defaultOGImage = '';

var Head = function Head(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    charSet: "UTF-8"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("title", null, props.title || ''), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "description",
    content: props.description || defaultDescription
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "viewport",
    content: "width=device-width, initial-scale=1"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "icon",
    sizes: "192x192",
    href: "/static/touch-icon.png"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "apple-touch-icon",
    href: "/static/touch-icon.png"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "mask-icon",
    href: "/static/favicon-mask.svg",
    color: "#49B882"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "icon",
    href: "/static/favicon.ico"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:url",
    content: props.url || defaultOGURL
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:title",
    content: props.title || ''
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:description",
    content: props.description || defaultDescription
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "twitter:site",
    content: props.url || defaultOGURL
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "twitter:card",
    content: "summary_large_image"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "twitter:image",
    content: props.ogImage || defaultOGImage
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:image",
    content: props.ogImage || defaultOGImage
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:image:width",
    content: "1200"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    property: "og:image:height",
    content: "630"
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (Head);

/***/ }),

/***/ "vAnC":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("---\r\ntitle: this is post3 title\r\nslug: post3\r\ncategory: general\r\n---\r\nAliquam est nulla, hendrerit sed finibus eget, scelerisque vitae nunc. Nunc quis tempus tortor. Fusce vestibulum fermentum elementum. Suspendisse vitae nibh et enim viverra tincidunt eu eget urna. Sed sollicitudin diam purus, sit amet tincidunt velit auctor nec. Maecenas consectetur elementum velit, vel consectetur justo malesuada nec. Mauris eu lectus turpis. Aliquam at feugiat nisl, ac viverra arcu. Proin in suscipit ex. Vestibulum ac augue nulla. Fusce tellus nisi, viverra vel finibus imperdiet, egestas sed dolor. Phasellus posuere in libero a molestie. Etiam neque mauris, semper eu leo vel, sagittis gravida lorem.\r\n\r\n<h1 style='color:red'>Aliquam in orci enim.</h1> Sed a lorem quis erat dictum commodo eget eget nunc. Nullam et aliquet sapien, et tempus nibh. Sed bibendum, elit ut mollis porttitor, nulla ligula semper justo, et lacinia dolor augue quis mi. Praesent felis arcu, congue vitae magna sed, fermentum facilisis mi. Pellentesque hendrerit tempus facilisis. Morbi sed odio non neque gravida fermentum. Suspendisse eget eros magna. Morbi et porta neque. Praesent mollis auctor lectus, eget varius neque egestas sit amet. Quisque vel magna ullamcorper, congue erat vitae, elementum quam. Curabitur sollicitudin eleifend lorem vitae blandit.\r\n\r\nInteger suscipit eros vitae mollis imperdiet. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. In velit nisl, condimentum eget elit vitae, pretium finibus velit. Sed a auctor lectus. Aliquam non ipsum eu augue accumsan sagittis. Nunc mi urna, molestie posuere consectetur sed, mattis at nisi. Morbi facilisis efficitur sapien, eget laoreet dolor vulputate in. Proin vel nibh velit. Praesent iaculis tellus in tellus pellentesque, ut fermentum leo dapibus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Pellentesque quis metus nec nibh lobortis ultrices non in quam. In in enim in urna lobortis auctor id sed odio. Aliquam placerat dui nec sapien lacinia, quis molestie eros tempor. Mauris est ipsum, fringilla ac hendrerit id, luctus at elit. Sed leo leo, sodales ac vestibulum interdum, porttitor ullamcorper neque. Vivamus ante ex, vehicula vitae odio vel, aliquam consequat dui.\r\n\r\nInterdum et malesuada fames ac ante ipsum primis in faucibus. Sed a nibh eu orci laoreet fermentum eu a lectus. Suspendisse suscipit, justo sed dictum hendrerit, orci nunc lacinia lectus, vel sagittis dolor risus nec mauris. Interdum et malesuada fames ac ante ipsum primis in faucibus. Mauris sed lacinia nisi. Etiam commodo in nibh a rutrum. Maecenas porttitor ultrices tellus ac ultricies. Etiam vehicula sagittis nulla sed semper. Ut pretium, purus sit amet blandit egestas, odio tellus tincidunt nisl, ut elementum felis sem sed sapien. Praesent convallis iaculis condimentum. Nullam posuere aliquam tincidunt.");

/***/ }),

/***/ "vjea":
/***/ (function(module, exports, __webpack_require__) {

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = _Object$setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

module.exports = _setPrototypeOf;

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ })

/******/ });