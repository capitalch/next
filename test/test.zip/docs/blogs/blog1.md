---
title: this is post1 title for the purpose of testing
slug: post1
category: general
---
<div style='color:red'>This is html123</div>

#### Proin eget velit vel mi pulvinar sagittis et nec augue. 

<table class = 'table'>
<tr>
    <td >col1</td>
</tr>
</table>

<pre><code class="language-javascript">
    // let x=0; 
    x++;
    y = x+=1;
    if ( x === y) {
        z = 200;
        z++;
    }

</code></pre>

```javascript
    function sayHello (msg, who) {
        return `${who} says: msg`;
    }
    sayHello("Hello World", "Johnny");
```


Cras felis purus, pellentesque et odio vel, dignissim semper mi. Sed non quam elit. Nam id nulla lacus. Vestibulum mollis enim at nibh tincidunt, id accumsan ligula dapibus. Donec sem justo, blandit et nulla sed, tincidunt aliquet neque. Phasellus ultrices et elit in molestie. Morbi tempus ut lacus vel efficitur. Aliquam erat volutpat. Duis pulvinar leo ut purus ullamcorper, nec cursus ligula hendrerit. Duis in diam dapibus, ullamcorper ipsum consectetur, malesuada justo. Vestibulum condimentum odio vitae nibh rutrum dictum.

Donec et feugiat risus. Aliquam pretium nulla ac neque interdum iaculis. Nullam et posuere mauris. Quisque arcu metus, bibendum non interdum ut, faucibus quis sapien. Phasellus tempus lacinia imperdiet. Vestibulum viverra id odio at scelerisque. In molestie accumsan faucibus. Quisque hendrerit in ipsum et lobortis. Maecenas consectetur dui ornare tincidunt semper. Sed quam augue, vestibulum sit amet ex et, eleifend interdum libero. Nulla id lorem quam. In fermentum felis velit, vitae vestibulum erat consectetur iaculis. Nullam malesuada tincidunt purus, ut auctor odio tincidunt ac. Morbi eu turpis et risus euismod suscipit non ut lorem. Donec vehicula commodo augue id ultrices.

Morbi dictum urna vitae nulla blandit fermentum. Aliquam lacinia, nisi at facilisis faucibus, lacus nibh aliquam purus, vel rhoncus magna quam at magna. Nunc fermentum tellus ac nisl aliquam vestibulum. Fusce pellentesque felis mi, eu vulputate ligula faucibus non. Duis vel aliquam mi, id mattis justo. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer ut ipsum sed eros pharetra pellentesque. Etiam mattis convallis nisi, sed luctus dolor eleifend at. In condimentum justo lectus, a feugiat felis convallis vel.