# About Sushant

I am a full stack software developer. I am in the software industry since last 3 decades back from year 2018. So far I have worked in capacity of Chief technology officer, Project manager, team lead, front end developer, back-end developer, Sql-developer, low end developer, technical architect, QA and also worked for pre-sales, deployment, training, migration and many more. Over period of time I gained experience in controlling finance, HR and operations, business development, legal of a business organization. I have solid domain knowledge of Financial accounting, inventory management, asset management, human relations and legal.

I hold a B.Tech degree in computer science and I started my carrier during DOS days working on DBASE, Clipper, assembly language and PowerBuilder during year 1990. I gradually learnt and did considerable software development work with  Microsoft technologies, SharePoint, dot net, Java, Sybase, Postgresql, JavaScript, Node.js, Angular, react.js, Flutter, dart, Cordova, Ionic and many more. I have given effect to several mission critical software projects in Financial accounting, Legal, Human resource management, payroll, Inventory management, Point of sales, Asset management, Engineering systems, Medical and health care and Legal domain.

I have seen many ups and downs in software industry and change in trends and technology. People say I am good in picking up new technologies and am a good self learner. I solve complex software problems after decomposing them to simple ones.  I excel in devising intelligent algorithms to solve intricate business problems.

In last few years we have seen a massive shift towards open source technologies and software development challenges have increased manifold. At this juncture of time the industry needs time and tested experienced software professionals who are also aware of the old systems. There is acute shortage of such skill-set in the software market. I am proud to say that I belong to such category of software professionals.

Presently in year 2018 I am associated with a multinational company as Chief Technology Officer. I am also doing low end software development work in several technologies as part of my job. I am hands on with latest technology such as ES6, Angular, React, Dart, nodejs and flutter. My company is doing well in terms of business and I am proud of being associated with this company.

I have sufficient free time at present and I am looking for business opportunities in challenging open source software development area.

Purpose of this blog site is to expose myself to the outside world. If somebody has great software development based business idea along with supporting finance and he / she is looking for strong and proven technical cum operational help in carrying out such idea, I am the right person to contact with.

I work from Kolkata, West Bengal, India and can be contacted at my email address capitalch@gmail.com
