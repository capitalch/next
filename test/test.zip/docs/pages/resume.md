# Resume of Sushant

<style>
td {
    border: 1px solid black;
    font-size:1rem;
}
</style>