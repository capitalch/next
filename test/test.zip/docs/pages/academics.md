### Academics of Sushant

<!-- | Period | Institute | Stream  |
| :---  |   :---   |      :----  |
| 1982 - 1986 | Birla Institute Of Technology, Mesra | B.Tech ( Computer Science ). Topped in the branch  |
| 1980 - 1982 | Scottish Church College | Class 11 + 12. (Pure Science) 63.2% marks  |
| 1976 – 1980 | Birla High School | Class 6 – Class 10. CBSE score was 80% |
| 1975 | Junior Hindi High School | Class 5 |
| 1969 – 1974 | Abhniv Bharti Balmandir | Class KG to Class 4. (Montessori) | -->
<table>
    <tr>
        <th>Period</th>
        <th>Institute</th>
        <th>Stream</th>
    </tr>
    <tr>
        <td>1982 - 1986</td>
        <td>Birla Institute Of Technology, Mesra</td>
        <td> B.Tech (Computer Science). Topped in the branch</td>
    </tr>
    <tr>
        <td>1980 - 1982</td>
        <td>Scottish Church College. (Pure Science) 63.2% marks</td>
        <td>Class 11 + 12</td>
    </tr>
    <tr>
        <td>1976 – 1980</td>
        <td>Birla High School</td>
        <td>Class 6 – Class 10. CBSE score was 80%</td>
    </tr>
    <tr>
        <td>1975</td>
        <td>Junior Hindi High School</td>
        <td>Class 5</td>
    </tr>
    <tr>
        <td>1969 – 1974</td>
        <td>Abhniv Bharti Balmandir</td>
        <td> Class KG to Class 4. (Montessori)</td>
    </tr>
</table>

I was always good in Alzebra and Science group. I had interest in English and Hindi languages. I can speak Bengali.

My educational certificates are below:
<div><a target='_blank' href='/static/documents/sushant-agrawal-higher-secondary-mark-sheet.pdf'>Higher Secondary mark Sheet</a></div>
<div><a target='_blank' href='/static/documents/susantagrawal_engineering-degree.pdf'>B.Tech. Engineering Degree</a></div>

<style>
    table {
        border-collapse: collapse;
        /* width:90%; */
    }


    td, th {
        border: 1px solid lightGrey;    
        padding: 0.1rem;
        /* margin:1rem; */
    }
    td {
        font-size: 1.0rem;
    }
    p {
        font-size: 1rem;
    }
</style>