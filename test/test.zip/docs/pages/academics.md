# Academics of Sushant

<div>Sushant was always good in Alzebra and Science group. He had interest in English and Hindi languages.</div>
<div>His educational certificates are below:</div>
<div><a href="https://sushant2018.files.wordpress.com/2018/05/sushant-agrawal-higher-secondary-mark-sheet.pdf">Higher Secondary mark Sheet</a>
<a href="https://sushant2018.files.wordpress.com/2018/05/susantagrawal_engineering-degree.pdf">B.Tech. Engineering Degree</a></div>